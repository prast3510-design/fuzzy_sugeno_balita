# 👶 Sistem Pakar Penyakit Balita – Fuzzy Sugeno (v2)

Aplikasi desktop berbasis **Python + Tkinter / ttkbootstrap** untuk mendiagnosis penyakit balita menggunakan metode **Fuzzy Sugeno**.

---

## ✨ Fitur Baru (v2)

| Fitur | Keterangan |
|-------|-----------|
| 🔐 Login | Sistem autentikasi username & password |
| 👥 Multi-Role | Role **Admin** & **User** dengan hak akses berbeda |
| 🛡 Proteksi Halaman | Halaman admin hanya bisa diakses oleh Administrator |
| 🚪 Logout | Tombol keluar di sidebar bawah |
| 🎨 UI Menarik | Panel login split (branding + form), sidebar dinamis |

---

## 🔑 Akun Default

| Role  | Username | Password  |
|-------|----------|-----------|
| Admin | `admin`  | `admin123` |
| User  | `user`   | `user123`  |

---

## 🚀 Cara Menjalankan

```bash
pip install ttkbootstrap
python main.py
```

---

## 📁 Struktur Proyek

```
balita_expert_v2/
├── main.py               ← Entry point & controller
├── database.py           ← SQLite CRUD (penyakit, gejala, rule, users)
├── auth.py               ← Autentikasi & manajemen sesi
├── fuzzy.py              ← Mesin inferensi Fuzzy Sugeno
├── requirements.txt
└── views/
    ├── login.py          ← Halaman login (BARU)
    ├── dashboard.py      ← Dashboard
    ├── input_gejala.py   ← Input gejala (checkbox)
    ├── hasil_diagnosis.py← Hasil diagnosis
    ├── admin_penyakit.py ← CRUD penyakit (admin only)
    ├── admin_gejala.py   ← CRUD gejala (admin only)
    └── admin_rule.py     ← CRUD rule (admin only)
```

---

## 🏥 Penyakit yang Didukung

- Diare
- ISPA (Infeksi Saluran Pernapasan Atas)
- Demam Berdarah Dengue (DBD)
- Campak
- Cacar Air (Varisela)
- Gizi Buruk
- Kejang Demam
