# Folder ini untuk menyimpan font kustom (.ttf, .otf)
# Gunakan di main.py atau views dengan tkinter font loader
# Contoh: font = ("CustomFont", 12) setelah load font
