# Folder ini untuk menyimpan ikon aplikasi
# Contoh: app_icon.ico, logo.png, dll.
# Gunakan di main.py dengan:
#
#   self.iconbitmap("assets/icons/app_icon.ico")   # Windows
#   img = tk.PhotoImage(file="assets/icons/logo.png")
