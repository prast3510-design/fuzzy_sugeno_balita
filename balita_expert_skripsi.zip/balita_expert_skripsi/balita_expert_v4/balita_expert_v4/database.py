"""
database.py - Modul pengelolaan database SQLite
Sistem Pakar Diagnosis Penyakit Balita - Metode Fuzzy Sugeno
"""

import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "balita_expert.db")


def get_connection():
    """Membuat dan mengembalikan koneksi ke database."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # Agar hasil query bisa diakses via nama kolom
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def initialize_database():
    """Membuat tabel-tabel jika belum ada dan mengisi data awal."""
    conn = get_connection()
    cursor = conn.cursor()

    # ── Tabel Users (Login) ───────────────────────────────────────────────────────
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            username      TEXT    NOT NULL UNIQUE,
            password_hash TEXT    NOT NULL,
            nama_lengkap  TEXT    NOT NULL,
            role          TEXT    NOT NULL DEFAULT 'user'
        )
    """)

    # Seed akun default
    import hashlib
    def _hash(pwd):
        return hashlib.sha256(f"balita_expert_salt_2025{pwd}".encode()).hexdigest()

    default_users = [
        ("admin", _hash("admin123"), "Bidan / Pakar", "admin"),
    ]
    cursor.executemany(
        "INSERT OR IGNORE INTO users (username, password_hash, nama_lengkap, role) VALUES (?,?,?,?)",
        default_users,
    )

    # ── Tabel Penyakit ──────────────────────────────────────────────────────────
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS penyakit (
            id      INTEGER PRIMARY KEY AUTOINCREMENT,
            kode    TEXT    NOT NULL UNIQUE,
            nama    TEXT    NOT NULL,
            deskripsi TEXT,
            solusi  TEXT
        )
    """)

    # ── Tabel Gejala ─────────────────────────────────────────────────────────────
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS gejala (
            id      INTEGER PRIMARY KEY AUTOINCREMENT,
            kode    TEXT    NOT NULL UNIQUE,
            nama    TEXT    NOT NULL,
            bobot   REAL    NOT NULL DEFAULT 1.0
        )
    """)

    # ── Tabel Rule Utama (Sugeno) ─────────────────────────────
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS rule (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            penyakit_id INTEGER NOT NULL,
            output REAL NOT NULL,
            FOREIGN KEY(penyakit_id) REFERENCES penyakit(id) ON DELETE CASCADE
        )
    """)

    # ── Tabel Detail Rule (multi gejala) ──────────────────────
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS rule_detail (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            rule_id INTEGER NOT NULL,
            gejala_id INTEGER NOT NULL,
            FOREIGN KEY(rule_id) REFERENCES rule(id) ON DELETE CASCADE,
            FOREIGN KEY(gejala_id) REFERENCES gejala(id) ON DELETE CASCADE
        )
    """)

    # ── Tabel Riwayat Penyakit Orang Tua (Master) ────────────────────────────────
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS riwayat_penyakit_ortu (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            kode         TEXT    NOT NULL UNIQUE,
            nama_penyakit TEXT   NOT NULL,
            keterangan   TEXT
        )
    """)

    # ── Tabel Imunisasi Dasar (Master) ───────────────────────────────────────────
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS imunisasi (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            kode           TEXT    NOT NULL UNIQUE,
            nama_imunisasi TEXT    NOT NULL,
            keterangan     TEXT
        )
    """)

    # ── Tabel Riwayat Diagnosis ───────────────────────────────────────────────────
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS riwayat_diagnosis (
            id                    INTEGER PRIMARY KEY AUTOINCREMENT,
            tanggal               TEXT    NOT NULL,
            nama_pasien           TEXT,
            umur_pasien           TEXT,
            jenis_kelamin         TEXT,
            gejala_ids_json       TEXT    NOT NULL DEFAULT '[]',
            riwayat_ortu_json     TEXT    NOT NULL DEFAULT '[]',
            status_imunisasi_json TEXT    NOT NULL DEFAULT '{}',
            hasil_json            TEXT    NOT NULL DEFAULT '[]'
        )
    """)

    # ── Migrasi kolom baru jika tabel lama sudah ada ─────────────────────────────
    existing_cols = [row[1] for row in cursor.execute("PRAGMA table_info(riwayat_diagnosis)").fetchall()]
    if "jenis_kelamin" not in existing_cols:
        cursor.execute("ALTER TABLE riwayat_diagnosis ADD COLUMN jenis_kelamin TEXT")
    if "riwayat_ortu_json" not in existing_cols:
        cursor.execute("ALTER TABLE riwayat_diagnosis ADD COLUMN riwayat_ortu_json TEXT NOT NULL DEFAULT '[]'")
    if "status_imunisasi_json" not in existing_cols:
        cursor.execute("ALTER TABLE riwayat_diagnosis ADD COLUMN status_imunisasi_json TEXT NOT NULL DEFAULT '{}'")

    # ── Seed Data Penyakit ────────────────────────────────────────────────────────
    penyakit_data = [
        ("P001", "Pneumonia Berat",
         "Ditandai dengan tarikan dinding dada kedalam / saturasi oksigen < 92%.",
         "Beri oksigen 1-4 L/menit dengan menggunakan nasal prongs, beri dosis pertama antibiotik yang sesuai, obati wheezing bila ada, RUJUK SEGERA."),
        ("P002", "Pneumonia",
         "Nafas cepat (anak umur 2-12 bulan 50 x/menit atau anak umur 12 bulan-5 tahun 40x/menit).",
         "Beri amoksilin 2x sehari selama 3 hari atau 5 hari, beri pelega tengggorokan dan pereda batuk yang aman, obati wheezing bila ada, apabila batuk > 2 minggu RUJUK untuk pemeriksaan TB dan sebab lain, kunjungan ulang 2 hari, nasihati kapan harus kembali segera."),
        ("P003", "Batuk Bukan Pneumonia",
         "Ditandai dengan adanya Batuk dan atau Sukar bernafas, Tidak ada tarikan dinding dada bagian bawah ke dalam (TDDK), Tidak ada napas cepat.",
         "Beri pelega tenggorokan dan pereda batuk yang aman, Obati wheezing bila ada, Apabila batuk ≥ 2 minggu, lacak kemungkinan TB, Kunjungan ulang 5 hari jika tidak ada perbaikan."),
        ("P004", "Diare Tanpa Dehidrasi",
         "Ditandai dengan Keadaan umum baik, Mata tidak cekung, minum seperti biasa dan tidak terlihat sangat haus atau lahap saat diberi minum, Saat dicubit kulit perut akan kembali dengan cepat (kurang dari 2 detik).",
         "Beri cairan, tablet zinc, dan makanan sesuai Rencana Terapi A, Kunjungan ulang 2 hari jika tidak ada perbaikan, Nasihati kapan harus kembali segera."),
        ("P005", "Diare Dehidrasi Ringan/Sedang",
         "Ditandai dengan dua atau lebih tanda-tanda yaitu Rewel/mudah marah, Mata cekung, Haus, minum dengan lahap, Cubitan kulit perut kembali lambat.",
         "Beri cairan, tablet zinc, dan makanan sesuai Rencana Terapi B Jika terdapat klasifikasi berat lain : RUJUK SEGERA, Jika masih bisa minum, berikan ASI dan larutan oralit selama perjalanan, Kunjungan ulang 2 hari jika tidak ada perbaikan, Nasihati kapan harus kembali segera."),
        ("P006", "Campak",
         "Gejala campak pada anak biasanya muncul 10–14 hari setelah terinfeksi. Penyakit ini umumnya diawali dengan demam tinggi, batuk, pilek, dan mata merah (konjungtivitis). Setelah beberapa hari, muncul ruam kemerahan yang khas, dimulai dari belakang telinga dan menyebar ke seluruh tubuh.",
         "Beri vitamin A dosis pengobatan, Nasihati kapan harus kembali segera."),
        ("P007", "Kejang Demam",
         "kondisi kejang yang terjadi pada anak usia 6 bulan hingga 5 tahun yang dipicu oleh kenaikan suhu tubuh (di atas 38°C) akibat infeksi di luar otak.",
         "Baringkan di tempat aman, Posisikan miring, Longgarkan pakaian, Jangan masukkan benda ke mulut, Catat durasi."),
        ("P008", "Flu Singapura, atau Hand, Foot, and Mouth Disease(HFMD)",
         "Ditandai dengan Demam, Luka atau sariawan yang menyakitkan di sekitar lidah, gusi, dan bagian dalam pipi muncul 1-2 hari setelah demam, Timbul bintik-bintik merah (biasanya tidak gatal) pada telapak tangan, telapak kaki, dan kadang di area bokong.",
         "Gunakan Parasetamol atau Ibuprofen untuk menurunkan panas dan mengurangi nyeri, Pastikan kebutuhan cairan tercukupi, Jika penderita kesulitan menelan akibat sariawan, berikan minuman bersuhu dingin seperti air es, air kelapa muda, atau jus buah, Isolasi mandiri selama 5-7 hari dan hindari berbagai peralatan makan atau kontak langsung guna mencegah penularan ke orang lain."),
    ]
    cursor.executemany(
        "INSERT OR IGNORE INTO penyakit (kode, nama, deskripsi, solusi) VALUES (?,?,?,?)",
        penyakit_data,
    )

    # ── Seed Data Gejala ──────────────────────────────────────────────────────────
    gejala_data = [
        ("G001", "Demam tinggi (> 38°C)",          1.0),
        ("G002", "Buang air besar cair / mencret",  1.0),
        ("G003", "Nafas Cepat",                     0.8),
        ("G004", "Batuk",                           0.8),
        ("G005", "Pilek / hidung tersumbat",        0.7),
        ("G006", "nyeri tenggorokan",               0.7),
        ("G007", "Sukar bernafas",                  1.0),
        ("G008", "Sariawan disekitar lidah, gusi dan bagian dalam pipi",                     0.9),
        ("G009", "Ruam merah menyebar",             1.0),
        ("G010", "Nafsu makan turun / tidak mau makan",                                      0.8),
        ("G011", "Tarikan dindin dada bagian bawah kedalam",                                 0.8),
        ("G012", "Mata cekung",                     0.7),
        ("G013", "Perut kembung / nyeri perut",     0.8),
        ("G014", "Rewel / mudah marah",             0.5),
        ("G015", "Cubitan kulit perut Kembali lambat",     0.5),
        ("G016", "Mata merah (konjungtivitis)",     0.3),
        ("G017", "Saturasi oksigen < 92%",          0.8),
        ("G018", "Bintik-bintik merah ditelapak tangan, kaki, dan area bokong",              0.8),
        ("G019", "Kejang",                          0.9),
        ("G020", "Keluar air liur berlebihan",      0.8),
        ("G021", "Pingsan atau kehilangan kesadaran",                                        0.8),
    ]
    cursor.executemany(
        "INSERT OR IGNORE INTO gejala (kode, nama, bobot) VALUES (?,?,?)",
        gejala_data,
    )

    # ── Seed Data Riwayat Penyakit Orang Tua ─────────────────────────────────────
    ortu_data = [
        ("RO001", "Asma",             "Penyakit saluran napas kronis"),
        ("RO002", "Alergi",           "Reaksi hipersensitivitas imun"),
        ("RO003", "Diabetes",         "Gangguan metabolisme glukosa"),
        ("RO004", "Hipertensi",       "Tekanan darah tinggi"),
        ("RO005", "Penyakit Jantung", "Gangguan fungsi jantung"),
        ("RO006", "Epilepsi",         "Gangguan saraf berulang"),
        ("RO007", "Tidak Ada",        "Tidak ada riwayat penyakit genetik"),
    ]
    cursor.executemany(
        "INSERT OR IGNORE INTO riwayat_penyakit_ortu (kode, nama_penyakit, keterangan) VALUES (?,?,?)",
        ortu_data,
    )

    # ── Seed Data Imunisasi Dasar ─────────────────────────────────────────────────
    imunisasi_data = [
        ("IMU001", "BCG",         "Imunisasi tuberkulosis, diberikan ketika sudah 1 bulan"),
        ("IMU002", "Hepatitis B", "Imunisasi hepatitis B, diberikan saat lahir"),
        ("IMU003", "Polio",       "Imunisasi polio, diberikan 4 kali"),
        ("IMU004", "OPV 1",       "imunisasi polio tetes kedua."),
        ("IMU005", "Campak/MR",   "Imunisasi campak dan rubela"),
        ("IMU006", "OPV 0",       "Imunisasi polio tetes pertama"),
        ("IMU007", "DPT-HB-Hib",  "Imunisasi difteri, Pertusis (batuk rejan), Tetanus, Hepatitis B, dan infeksi Haemophilus influenzae tipe b"),
        ("IMU008", "PCV",         "imunisasi pneumonia, meningitis, dan infeksi telinga"),
    ]
    cursor.executemany(
        "INSERT OR IGNORE INTO imunisasi (kode, nama_imunisasi, keterangan) VALUES (?,?,?)",
        imunisasi_data,
    )

    # ── Helper: dapatkan id ──────────────────────────────────────────────────────
    def pid(kode):
        return cursor.execute("SELECT id FROM penyakit WHERE kode=?", (kode,)).fetchone()[0]

    def gid(kode):
        return cursor.execute("SELECT id FROM gejala WHERE kode=?", (kode,)).fetchone()[0]

    # ── SEED RULE SUGENO ─────────────────────────────────────
    cursor.execute("DELETE FROM rule")
    cursor.execute("DELETE FROM rule_detail")

    def add_rule(p_kode, gejala_list, output):
        cursor.execute(
            "INSERT INTO rule (penyakit_id, output) VALUES (?,?)",
            (pid(p_kode), output)
        )
        rule_id = cursor.lastrowid

        for g in gejala_list:
            cursor.execute(
                "INSERT INTO rule_detail (rule_id, gejala_id) VALUES (?,?)",
                (rule_id, gid(g))
            )
        if not gejala_list:
            return

    # PNEUMONIA BERAT
    add_rule("P001", ["G004", "G011", "G017"], 0.8)
    add_rule("P001", ["G007", "G011", "G017"], 0.9)

     # PNEUMONIA
    add_rule("P002", ["G003", "G007"], 0.9)

    # BATUK BUKAN PNEUMONIA
    add_rule("P003", ["G001", "G007"], 0.85)
    add_rule("P003", ["G001", "G004"], 0.95)

    # DIARE TANPA DEHIDRASI
    add_rule("P004", ["G002", "G013"], 0.9)

    # DIARE DEHIDRASI RINGAN / SEDANG
    add_rule("P005", ["G002", "G010"], 0.8)
    add_rule("P005", ["G002", "G010", "G015"], 0.9)

    # CAMPAK
    add_rule("P006", ["G001", "G004", "G005", "G009"], 0.85)
    add_rule("P006", ["G001", "G004", "G005", "G009", "G016"], 0.85)

    # KEJANG DEMAM
    add_rule("P007", ["G001", "G019"], 0.85)
    add_rule("P007", ["G001", "G019", "G021"], 0.95)
    add_rule("P007", ["G001", "G019", "G020"], 0.9)

    # FLU SINGAPURA, ATAU HAND, FOOT, AND MOUTH DISEASE (HFMD)
    add_rule("P008", ["G001", "G005", "G008"], 0.95)
    add_rule("P008", ["G001", "G005", "G006"], 0.95)
    conn.commit()
    conn.close()


# ── CRUD Penyakit ─────────────────────────────────────────────────────────────

def get_all_penyakit():
    with get_connection() as conn:
        return conn.execute("SELECT * FROM penyakit ORDER BY kode").fetchall()

def get_penyakit_by_id(pid):
    with get_connection() as conn:
        return conn.execute("SELECT * FROM penyakit WHERE id=?", (pid,)).fetchone()

def insert_penyakit(kode, nama, deskripsi, solusi):
    with get_connection() as conn:
        conn.execute(
            "INSERT INTO penyakit (kode, nama, deskripsi, solusi) VALUES (?,?,?,?)",
            (kode, nama, deskripsi, solusi),
        )

def update_penyakit(pid, kode, nama, deskripsi, solusi):
    with get_connection() as conn:
        conn.execute(
            "UPDATE penyakit SET kode=?, nama=?, deskripsi=?, solusi=? WHERE id=?",
            (kode, nama, deskripsi, solusi, pid),
        )

def delete_penyakit(pid):
    with get_connection() as conn:
        conn.execute("DELETE FROM penyakit WHERE id=?", (pid,))


# ── CRUD Gejala ───────────────────────────────────────────────────────────────

def get_all_gejala():
    with get_connection() as conn:
        return conn.execute("SELECT * FROM gejala ORDER BY kode").fetchall()

def get_gejala_by_id(gid):
    with get_connection() as conn:
        return conn.execute("SELECT * FROM gejala WHERE id=?", (gid,)).fetchone()

def insert_gejala(kode, nama, bobot):
    with get_connection() as conn:
        conn.execute(
            "INSERT INTO gejala (kode, nama, bobot) VALUES (?,?,?)",
            (kode, nama, float(bobot)),
        )

def update_gejala(gid, kode, nama, bobot):
    with get_connection() as conn:
        conn.execute(
            "UPDATE gejala SET kode=?, nama=?, bobot=? WHERE id=?",
            (kode, nama, float(bobot), gid),
        )

def delete_gejala(gid):
    with get_connection() as conn:
        conn.execute("DELETE FROM gejala WHERE id=?", (gid,))


# ── CRUD Rule ─────────────────────────────────────────────────────────────────

def get_rules_grouped():
    with get_connection() as conn:
        rows = conn.execute("""
            SELECT r.id AS rule_id,
                   r.penyakit_id,
                   r.output,
                   rd.gejala_id
            FROM rule r
            JOIN rule_detail rd ON r.id = rd.rule_id
        """).fetchall()

    rules = {}

    for row in rows:
        rid = row["rule_id"]

        if rid not in rules:
            rules[rid] = {
                "penyakit_id": row["penyakit_id"],
                "output": row["output"],
                "gejala": []
            }

        rules[rid]["gejala"].append(row["gejala_id"])

    return list(rules.values())


def get_all_rules():
    """
    Mengambil semua rule, satu baris per rule.
    Gejala yang ada dalam satu rule digabung dengan koma.
    """
    with get_connection() as conn:
        rules = conn.execute("""
            SELECT r.id, r.output AS nilai_cf,
                   p.id AS penyakit_id,
                   p.kode AS kode_penyakit,
                   p.nama AS nama_penyakit
            FROM rule r
            JOIN penyakit p ON r.penyakit_id = p.id
            ORDER BY r.id DESC
        """).fetchall()

        result = []
        for r in rules:
            gejala_rows = conn.execute("""
                SELECT g.kode, g.nama
                FROM rule_detail rd
                JOIN gejala g ON rd.gejala_id = g.id
                WHERE rd.rule_id = ?
            """, (r["id"],)).fetchall()

            nama_gejala = ", ".join(g["nama"] for g in gejala_rows)

            result.append({
                "id": r["id"],
                "nilai_cf": r["nilai_cf"],
                "penyakit_id": r["penyakit_id"],
                "kode_penyakit": r["kode_penyakit"],
                "nama_penyakit": r["nama_penyakit"],
                "nama_gejala": nama_gejala,
            })

        return result


def insert_rule(penyakit_id, gejala_ids, output):
    if isinstance(gejala_ids, int):
        gejala_ids = [gejala_ids]

    with get_connection() as conn:
        cursor = conn.cursor()

        cursor.execute(
            "INSERT INTO rule (penyakit_id, output) VALUES (?, ?)",
            (penyakit_id, output)
        )

        rule_id = cursor.lastrowid

        for gid in gejala_ids:
            cursor.execute(
                "INSERT INTO rule_detail (rule_id, gejala_id) VALUES (?, ?)",
                (rule_id, gid)
            )


def update_rule(rule_id, penyakit_id, gejala_ids, output):
    if isinstance(gejala_ids, int):
        gejala_ids = [gejala_ids]

    with get_connection() as conn:
        cursor = conn.cursor()

        cursor.execute(
            "UPDATE rule SET penyakit_id=?, output=? WHERE id=?",
            (penyakit_id, output, rule_id)
        )

        cursor.execute(
            "DELETE FROM rule_detail WHERE rule_id=?",
            (rule_id,)
        )

        for gid in gejala_ids:
            cursor.execute(
                "INSERT INTO rule_detail (rule_id, gejala_id) VALUES (?, ?)",
                (rule_id, gid)
            )


def delete_rule(rule_id):
    with get_connection() as conn:
        conn.execute("DELETE FROM rule WHERE id=?", (rule_id,))


# ── CRUD Users ─────────────────────────────────────────────────────────────────

def get_user_by_credentials(username: str, password_hash: str):
    with get_connection() as conn:
        return conn.execute(
            "SELECT * FROM users WHERE username=? AND password_hash=?",
            (username, password_hash),
        ).fetchone()

def get_all_users():
    with get_connection() as conn:
        return conn.execute(
            "SELECT id, username, nama_lengkap, role FROM users ORDER BY id"
        ).fetchall()

def get_user_by_id(uid):
    with get_connection() as conn:
        return conn.execute(
            "SELECT id, username, nama_lengkap, role FROM users WHERE id=?", (uid,)
        ).fetchone()

def insert_user(username, password_hash, nama_lengkap, role="user"):
    with get_connection() as conn:
        conn.execute(
            "INSERT INTO users (username, password_hash, nama_lengkap, role) VALUES (?,?,?,?)",
            (username, password_hash, nama_lengkap, role),
        )

def update_user(uid, username, nama_lengkap, role):
    with get_connection() as conn:
        conn.execute(
            "UPDATE users SET username=?, nama_lengkap=?, role=? WHERE id=?",
            (username, nama_lengkap, role, uid),
        )

def update_user_password(uid, password_hash):
    with get_connection() as conn:
        conn.execute(
            "UPDATE users SET password_hash=? WHERE id=?",
            (password_hash, uid),
        )

def delete_user(uid):
    with get_connection() as conn:
        conn.execute("DELETE FROM users WHERE id=?", (uid,))


# ── CRUD Riwayat Penyakit Orang Tua ──────────────────────────────────────────

def get_all_riwayat_ortu():
    with get_connection() as conn:
        return conn.execute(
            "SELECT * FROM riwayat_penyakit_ortu ORDER BY kode"
        ).fetchall()

def get_riwayat_ortu_by_id(rid):
    with get_connection() as conn:
        return conn.execute(
            "SELECT * FROM riwayat_penyakit_ortu WHERE id=?", (rid,)
        ).fetchone()

def insert_riwayat_ortu(kode, nama_penyakit, keterangan=""):
    with get_connection() as conn:
        conn.execute(
            "INSERT INTO riwayat_penyakit_ortu (kode, nama_penyakit, keterangan) VALUES (?,?,?)",
            (kode, nama_penyakit, keterangan),
        )

def update_riwayat_ortu(rid, kode, nama_penyakit, keterangan=""):
    with get_connection() as conn:
        conn.execute(
            "UPDATE riwayat_penyakit_ortu SET kode=?, nama_penyakit=?, keterangan=? WHERE id=?",
            (kode, nama_penyakit, keterangan, rid),
        )

def delete_riwayat_ortu(rid):
    with get_connection() as conn:
        conn.execute("DELETE FROM riwayat_penyakit_ortu WHERE id=?", (rid,))


# ── CRUD Imunisasi ────────────────────────────────────────────────────────────

def get_all_imunisasi():
    with get_connection() as conn:
        return conn.execute(
            "SELECT * FROM imunisasi ORDER BY kode"
        ).fetchall()

def get_imunisasi_by_id(iid):
    with get_connection() as conn:
        return conn.execute(
            "SELECT * FROM imunisasi WHERE id=?", (iid,)
        ).fetchone()

def insert_imunisasi(kode, nama_imunisasi, keterangan=""):
    with get_connection() as conn:
        conn.execute(
            "INSERT INTO imunisasi (kode, nama_imunisasi, keterangan) VALUES (?,?,?)",
            (kode, nama_imunisasi, keterangan),
        )

def update_imunisasi(iid, kode, nama_imunisasi, keterangan=""):
    with get_connection() as conn:
        conn.execute(
            "UPDATE imunisasi SET kode=?, nama_imunisasi=?, keterangan=? WHERE id=?",
            (kode, nama_imunisasi, keterangan, iid),
        )

def delete_imunisasi(iid):
    with get_connection() as conn:
        conn.execute("DELETE FROM imunisasi WHERE id=?", (iid,))


# ── CRUD Riwayat Diagnosis ────────────────────────────────────────────────────

def get_all_riwayat():
    """Ambil semua riwayat, urut terbaru di atas."""
    with get_connection() as conn:
        return conn.execute(
            "SELECT * FROM riwayat_diagnosis ORDER BY id DESC"
        ).fetchall()

def get_riwayat_by_id(rid):
    with get_connection() as conn:
        return conn.execute(
            "SELECT * FROM riwayat_diagnosis WHERE id=?", (rid,)
        ).fetchone()

def insert_riwayat(tanggal: str, nama_pasien: str, umur_pasien: str,
                   gejala_ids_json: str, hasil_json: str,
                   jenis_kelamin: str = "",
                   riwayat_ortu_json: str = "[]",
                   status_imunisasi_json: str = "{}"):
    """Simpan satu sesi diagnosis ke tabel riwayat."""
    with get_connection() as conn:
        conn.execute(
            """INSERT INTO riwayat_diagnosis
               (tanggal, nama_pasien, umur_pasien, jenis_kelamin,
                gejala_ids_json, riwayat_ortu_json, status_imunisasi_json, hasil_json)
               VALUES (?,?,?,?,?,?,?,?)""",
            (tanggal, nama_pasien, umur_pasien, jenis_kelamin,
             gejala_ids_json, riwayat_ortu_json, status_imunisasi_json, hasil_json),
        )

def delete_riwayat(rid):
    with get_connection() as conn:
        conn.execute("DELETE FROM riwayat_diagnosis WHERE id=?", (rid,))

def delete_all_riwayat():
    with get_connection() as conn:
        conn.execute("DELETE FROM riwayat_diagnosis")


# ── Statistik Dashboard ───────────────────────────────────────────────────────

def get_stats_dashboard():
    """Mengambil statistik untuk dashboard."""
    import json
    from collections import Counter

    with get_connection() as conn:
        total_diagnosa = conn.execute(
            "SELECT COUNT(*) FROM riwayat_diagnosis"
        ).fetchone()[0]

        semua = conn.execute(
            "SELECT hasil_json, riwayat_ortu_json, status_imunisasi_json FROM riwayat_diagnosis"
        ).fetchall()

    penyakit_counter = Counter()
    ortu_counter = Counter()
    belum_lengkap = 0

    for row in semua:
        # Penyakit terbanyak
        try:
            hasil = json.loads(row["hasil_json"] or "[]")
            if hasil:
                penyakit_counter[hasil[0].get("nama_penyakit", "")] += 1
        except Exception:
            pass

        # Riwayat ortu terbanyak
        try:
            ortu_list = json.loads(row["riwayat_ortu_json"] or "[]")
            for o in ortu_list:
                if o and o != "Tidak Ada":
                    ortu_counter[o] += 1
        except Exception:
            pass

        # Imunisasi belum lengkap
        try:
            imu = json.loads(row["status_imunisasi_json"] or "{}")
            if any(v == "Belum" for v in imu.values()):
                belum_lengkap += 1
        except Exception:
            pass

    penyakit_terbanyak = penyakit_counter.most_common(1)
    ortu_terbanyak = ortu_counter.most_common(1)

    return {
        "total_diagnosa": total_diagnosa,
        "penyakit_terbanyak": penyakit_terbanyak[0][0] if penyakit_terbanyak else "-",
        "penyakit_terbanyak_count": penyakit_terbanyak[0][1] if penyakit_terbanyak else 0,
        "ortu_terbanyak": ortu_terbanyak[0][0] if ortu_terbanyak else "-",
        "ortu_terbanyak_count": ortu_terbanyak[0][1] if ortu_terbanyak else 0,
        "belum_lengkap_imunisasi": belum_lengkap,
    }
