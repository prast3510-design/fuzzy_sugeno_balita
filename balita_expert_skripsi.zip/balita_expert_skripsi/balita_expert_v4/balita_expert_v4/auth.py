"""
auth.py - Modul Autentikasi & Manajemen Sesi
Sistem Pakar Diagnosis Penyakit Balita - Metode Fuzzy Sugeno
"""

import hashlib
import os
import database as db


# ── State Sesi Global ─────────────────────────────────────────────────────────

_current_user: dict | None = None


def hash_password(password: str) -> str:
    """Hash password menggunakan SHA-256 dengan salt."""
    salt = "balita_expert_salt_2025"
    return hashlib.sha256(f"{salt}{password}".encode()).hexdigest()


def login(username: str, password: str) -> tuple[bool, str]:
    """
    Mencoba login dengan username dan password.
    Mengembalikan (success: bool, message: str).
    """
    global _current_user

    if not username.strip() or not password.strip():
        return False, "Username dan password wajib diisi."

    hashed = hash_password(password)
    user = db.get_user_by_credentials(username.strip(), hashed)

    if user is None:
        return False, "Username atau password salah."

    _current_user = dict(user)
    return True, f"Selamat datang, {user['nama_lengkap']}!"


def logout():
    """Logout dan hapus sesi."""
    global _current_user
    _current_user = None


def get_current_user() -> dict | None:
    """Mengembalikan data user yang sedang login, atau None."""
    return _current_user


def is_logged_in() -> bool:
    return _current_user is not None


def is_admin() -> bool:
    """Cek apakah user yang login adalah admin."""
    if _current_user is None:
        return False
    return _current_user.get("role") == "admin"


def get_display_name() -> str:
    if _current_user:
        return _current_user.get("nama_lengkap", _current_user.get("username", ""))
    return ""


def get_role_label() -> str:
    if _current_user:
        role = _current_user.get("role", "user")
        return "Administrator" if role == "admin" else "Pengguna"
    return ""
