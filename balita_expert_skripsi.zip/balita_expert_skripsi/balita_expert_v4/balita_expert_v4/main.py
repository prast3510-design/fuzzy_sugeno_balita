"""
main.py - Entry Point Aplikasi
Sistem Pakar Diagnosis Penyakit Balita – Metode Fuzzy Sugeno
"""

import sys
import os

sys.path.insert(0, os.path.dirname(__file__))

import tkinter as tk
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from ttkbootstrap.dialogs import Messagebox

import database as db
import auth
from views.login              import LoginPage
from views.dashboard          import DashboardPage
from views.input_gejala       import InputGejalaPage
from views.hasil_diagnosis    import HasilDiagnosisPage
from views.riwayat_diagnosis  import RiwayatDiagnosisPage
from views.admin_penyakit     import AdminPenyakitPage
from views.admin_gejala       import AdminGejalaPage
from views.admin_rule         import AdminRulePage
from views.admin_ortu         import AdminOrtuPage
from views.admin_imunisasi    import AdminImunisasiPage


# ── Konfigurasi Menu Sidebar ──────────────────────────────────────────────────

MENU_ITEMS = [
    # (label, page_key, admin_only)
    ("Dashboard",       "Dashboard",      True),
    ("Diagnosis Pasien","InputGejala",    True),
    ("Riwayat Pasien",  "Riwayat",        True),
    (None,              None,             True),   # separator
    ("Data Penyakit",   "AdminPenyakit",  True),
    ("Data Gejala",     "AdminGejala",    True),
    ("Data Rule",       "AdminRule",      True),
    ("Riwayat Penyakit Ortu", "AdminOrtu", True),
    ("Data Imunisasi",  "AdminImunisasi", True),
]


# ── Aplikasi Utama ────────────────────────────────────────────────────────────

class App(ttk.Window):
    def __init__(self):
        super().__init__(
            title="Sistem Pakar Penyakit Balita – Fuzzy Sugeno",
            themename="lumen",
            size=(1150, 720),
            minsize=(900, 580),
        )
        self.resizable(True, True)
        db.initialize_database()

        self._pages: dict = {}
        self._current_page: str = ""
        self._btn_refs: dict = {}
        self._main_wrapper = None
        self._login_frame = None

        self._show_login_screen()

    # ── Login ─────────────────────────────────────────────────────────────────

    def _show_login_screen(self):
        if self._login_frame is not None:
            try:
                self._login_frame.destroy()
            except Exception:
                pass

        if self._main_wrapper:
            self._main_wrapper.pack_forget()

        self._login_frame = LoginPage(self, on_success=self._on_login_success)
        self._login_frame.pack(fill=BOTH, expand=True)

    def _on_login_success(self):
        self._login_frame.pack_forget()
        self._login_frame.destroy()
        self._login_frame = None

        if self._main_wrapper is None or not self._main_wrapper.winfo_exists():
            self._build_main_layout()
        else:
            self._main_wrapper.pack(fill=BOTH, expand=True)
            self._refresh_sidebar()

        self.show_page("Dashboard")

    # ── Main Layout ───────────────────────────────────────────────────────────

    def _build_main_layout(self):
        self._main_wrapper = ttk.Frame(self)
        self._main_wrapper.pack(fill=BOTH, expand=True)
        self._build_sidebar()
        self._build_content()
        self._register_pages()

    def _build_sidebar(self):
        self.sidebar = ttk.Frame(self._main_wrapper, bootstyle="dark", width=220)
        self.sidebar.pack(side=LEFT, fill=Y)
        self.sidebar.pack_propagate(False)

        brand = ttk.Frame(self.sidebar, bootstyle="dark")
        brand.pack(fill=X, padx=12, pady=16)
        ttk.Label(brand, text="Pakar Balita",
                  font=("Segoe UI", 13, "bold"),
                  bootstyle="inverse-dark").pack()
        ttk.Label(brand, text="Fuzzy Sugeno",
                  font=("Segoe UI", 8),
                  foreground="#888",
                  bootstyle="inverse-dark").pack()

        ttk.Separator(self.sidebar, bootstyle="secondary").pack(fill=X, pady=6)

        self._menu_frame = ttk.Frame(self.sidebar, bootstyle="dark")
        self._menu_frame.pack(fill=X)
        self._build_menu_buttons()

        self._sep_bottom = ttk.Separator(self.sidebar, bootstyle="secondary")
        self._sep_bottom.pack(side=BOTTOM, fill=X)
        self._user_frame = ttk.Frame(self.sidebar, bootstyle="dark")
        self._user_frame.pack(side=BOTTOM, fill=X, padx=10, pady=12)
        self._build_user_info()

    def _build_menu_buttons(self):
        for w in self._menu_frame.winfo_children():
            w.destroy()
        self._btn_refs.clear()

        is_admin = auth.is_admin()

        for item in MENU_ITEMS:
            label, page_key, admin_only = item

            if page_key is None:
                if is_admin:
                    ttk.Label(
                        self._menu_frame,
                        text="  ADMIN PANEL",
                        font=("Segoe UI", 7, "bold"),
                        foreground="#666",
                        bootstyle="inverse-dark",
                    ).pack(fill=X, padx=10, pady=(10, 2))
                continue

            if admin_only and not is_admin:
                continue

            btn = ttk.Button(
                self._menu_frame,
                text=f"  {label}",
                bootstyle="dark",
                command=lambda pk=page_key, ao=admin_only: self._on_menu_click(pk, ao),
                padding=(10, 9),
                width=22,
            )
            btn.pack(fill=X, padx=6, pady=2)
            self._btn_refs[page_key] = btn

    def _build_user_info(self):
        for w in self._user_frame.winfo_children():
            w.destroy()

        user = auth.get_current_user()
        if not user:
            return

        role_label = auth.get_role_label() if hasattr(auth, "get_role_label") else ""

        ttk.Label(self._user_frame,
                  text=user["nama_lengkap"],
                  font=("Segoe UI", 9, "bold"),
                  foreground="white",
                  bootstyle="inverse-dark",
                  wraplength=180).pack(anchor=W)

        ttk.Label(self._user_frame,
                  text=f"{role_label}  @{user['username']}",
                  font=("Segoe UI", 8),
                  foreground="#999",
                  bootstyle="inverse-dark").pack(anchor=W, pady=(1, 8))

        ttk.Button(self._user_frame,
                   text="Keluar",
                   bootstyle="danger-outline",
                   command=self._do_logout,
                   width=18).pack(fill=X)

    def _build_content(self):
        self.content = ttk.Frame(self._main_wrapper)
        self.content.pack(side=LEFT, fill=BOTH, expand=True)

    def _register_pages(self):
        page_classes = {
            "Dashboard":       DashboardPage,
            "InputGejala":     InputGejalaPage,
            "HasilDiagnosis":  HasilDiagnosisPage,
            "Riwayat":         RiwayatDiagnosisPage,
            "AdminPenyakit":   AdminPenyakitPage,
            "AdminGejala":     AdminGejalaPage,
            "AdminRule":       AdminRulePage,
            "AdminOrtu":       AdminOrtuPage,
            "AdminImunisasi":  AdminImunisasiPage,
        }
        self._pages.clear()
        for key, cls in page_classes.items():
            page = cls(self.content, controller=self)
            page.place(relwidth=1, relheight=1)
            self._pages[key] = page

    # ── Navigation ────────────────────────────────────────────────────────────

    def _on_menu_click(self, page_key: str, admin_only: bool):
        print("DIKLIK:", page_key)
        if admin_only and not auth.is_admin():
            Messagebox.show_warning(
                title="Akses Ditolak",
                message="Fitur ini hanya tersedia untuk Administrator.",
                parent=self)
            return
        self.show_page(page_key)

    def show_page(self, page_key: str, data=None):
        print("BUKA PAGE:", page_key)
        if page_key not in self._pages:
            return
        page = self._pages[page_key]
        if data is not None and hasattr(page, "set_data"):
            page.set_data(data)
        if hasattr(page, "refresh"):
            try:
                page.refresh()
            except Exception as e:
                print("ERROR DI PAGE:", e)
        page.lift()
        self._current_page = page_key
        for key, btn in self._btn_refs.items():
            btn.configure(bootstyle="success" if key == page_key else "dark")

    def _refresh_sidebar(self):
        self._build_menu_buttons()
        self._build_user_info()

    # ── Logout ────────────────────────────────────────────────────────────────

    def _do_logout(self):
        confirm = Messagebox.yesno(
            title="Konfirmasi Keluar",
            message=f"Yakin ingin keluar dari akun {auth.get_display_name()}?",
            parent=self)
        if confirm == "Yes":
            auth.logout()
            if self._main_wrapper:
                self._main_wrapper.pack_forget()
            self._show_login_screen()


# ── Entry Point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    app = App()
    app.mainloop()
