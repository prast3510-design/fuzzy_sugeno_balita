"""
views/admin_rule.py - Admin Panel: CRUD Data Rule (Aturan Fuzzy)
Gejala multi-select menggunakan Listbox dengan Ctrl+Klik / Shift+Klik
"""

import tkinter as tk
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from ttkbootstrap.dialogs import Messagebox
import database as db


class AdminRulePage(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self._selected_id = None
        self._penyakit_map = {}   # label -> id
        self._gejala_labels = []  # urutan label gejala di listbox
        self._gejala_map = {}     # label -> id
        self._build_ui()

    # ─────────────────────────────────────────────────────────────────────────
    def _build_ui(self):
        # ── Header ───────────────────────────────────────────────────────────
        hdr = ttk.Frame(self, bootstyle="info", padding=(20, 10))
        hdr.pack(fill=X)
        ttk.Label(hdr, text="Admin – Data Rule (Aturan Fuzzy)",
                  font=("Segoe UI", 14, "bold"),
                  bootstyle="inverse-info").pack(side=LEFT)

        # ── Body ─────────────────────────────────────────────────────────────
        body = ttk.Frame(self, padding=15)
        body.pack(fill=BOTH, expand=True)
        body.columnconfigure(0, weight=3)
        body.columnconfigure(1, weight=2)
        body.rowconfigure(0, weight=1)

        # ── Kiri: Tabel ───────────────────────────────────────────────────────
        left = ttk.Frame(body)
        left.grid(row=0, column=0, sticky=NSEW, padx=(0, 10))

        ttk.Label(left, text="Daftar Rule",
                  font=("Segoe UI", 11, "bold")).pack(anchor=W, pady=(0, 8))

        table_box = ttk.Frame(left)
        table_box.pack(fill=BOTH, expand=True)

        cols = ("Penyakit", "Gejala", "CF")
        self.tree = ttk.Treeview(table_box, columns=cols,
                                 show="headings", bootstyle="info",
                                 selectmode="browse", height=18)
        self.tree.heading("Penyakit", text="Penyakit", anchor=W)
        self.tree.heading("Gejala",   text="Gejala",   anchor=W)
        self.tree.heading("CF",       text="CF (0–1)", anchor=CENTER)
        self.tree.column("Penyakit", width=160, anchor=W)
        self.tree.column("Gejala",   width=240, anchor=W)
        self.tree.column("CF",       width=70,  anchor=CENTER, stretch=False)

        vsb = ttk.Scrollbar(table_box, orient=VERTICAL,
                             command=self.tree.yview, bootstyle="round")
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side=LEFT, fill=BOTH, expand=True)
        vsb.pack(side=RIGHT, fill=Y)
        self.tree.bind("<<TreeviewSelect>>", self._on_select)

        # ── Kanan: Form ───────────────────────────────────────────────────────
        form = ttk.Frame(body, padding=15, bootstyle="light")
        form.grid(row=0, column=1, sticky=NSEW)

        ttk.Label(form, text="Form Rule",
                  font=("Segoe UI", 11, "bold")).pack(anchor=W, pady=(0, 10))

        # Penyakit
        ttk.Label(form, text="Penyakit *",
                  font=("Segoe UI", 9, "bold")).pack(anchor=W, pady=(8, 2))
        self.cmb_penyakit = ttk.Combobox(form, state="readonly")
        self.cmb_penyakit.pack(fill=X)

        # Gejala – Listbox multi-select
        ttk.Label(form, text="Gejala * (pilih satu atau lebih)",
                  font=("Segoe UI", 9, "bold")).pack(anchor=W, pady=(12, 2))

        ttk.Label(form,
                  text="Ctrl+Klik = pilih banyak  |  Shift+Klik = pilih rentang",
                  font=("Segoe UI", 8), foreground="#888").pack(anchor=W, pady=(0, 4))

        listbox_frame = ttk.Frame(form)
        listbox_frame.pack(fill=BOTH, expand=True)

        self.lb_gejala = tk.Listbox(
            listbox_frame,
            selectmode=tk.MULTIPLE,
            height=10,
            exportselection=False,
            font=("Segoe UI", 9),
            activestyle="dotbox",
            selectbackground="#0d6efd",
            selectforeground="white",
            relief="flat",
            bd=1,
            highlightthickness=1,
            highlightbackground="#dee2e6",
        )
        lb_sb = ttk.Scrollbar(listbox_frame, orient=VERTICAL,
                              command=self.lb_gejala.yview, bootstyle="round")
        self.lb_gejala.configure(yscrollcommand=lb_sb.set)
        self.lb_gejala.pack(side=LEFT, fill=BOTH, expand=True)
        lb_sb.pack(side=RIGHT, fill=Y)

        # Tombol Pilih Semua / Hapus Semua
        quick_frame = ttk.Frame(form)
        quick_frame.pack(fill=X, pady=(4, 0))
        ttk.Button(quick_frame, text="Pilih Semua", bootstyle="secondary-outline",
                   command=self._select_all_gejala).pack(side=LEFT, padx=(0, 6))
        ttk.Button(quick_frame, text="Hapus Pilihan", bootstyle="secondary-outline",
                   command=self._clear_gejala).pack(side=LEFT)

        # Label gejala terpilih
        self.lbl_terpilih = ttk.Label(form, text="Terpilih: 0 gejala",
                                      font=("Segoe UI", 8), foreground="#0d6efd")
        self.lbl_terpilih.pack(anchor=W, pady=(4, 0))
        self.lb_gejala.bind("<<ListboxSelect>>", self._on_listbox_change)

        # Nilai CF
        ttk.Label(form, text="Nilai CF (0.0 – 1.0) *",
                  font=("Segoe UI", 9, "bold")).pack(anchor=W, pady=(12, 2))
        self.ent_cf = ttk.Entry(form)
        self.ent_cf.pack(fill=X)
        ttk.Label(form,
                  text="Contoh: 1.0 = pasti, 0.9 = sangat tinggi, 0.8 = tinggi",
                  font=("Segoe UI", 8), foreground="#888").pack(anchor=W, pady=(4, 0))

        # Tombol aksi
        btn = ttk.Frame(form, padding=(0, 14))
        btn.pack(fill=X)
        ttk.Button(btn, text="Tambah",  bootstyle="success",
                   command=self._tambah).pack(side=LEFT, padx=(0, 5))
        ttk.Button(btn, text="Ubah",    bootstyle="warning",
                   command=self._ubah).pack(side=LEFT, padx=5)
        ttk.Button(btn, text="Hapus",   bootstyle="danger",
                   command=self._hapus).pack(side=LEFT, padx=5)
        ttk.Button(btn, text="Reset",   bootstyle="secondary",
                   command=self._reset_form).pack(side=RIGHT)
        ttk.Button(btn, text="🖨 Cetak Laporan", bootstyle="primary",
                   command=self._cetak_laporan).pack(side=RIGHT, padx=(0, 5))

        self._reload_combos()
        self._load_data()

    # ─────────────────────────────────────────────────────────────────────────
    # Listbox helpers
    # ─────────────────────────────────────────────────────────────────────────
    def _on_listbox_change(self, _event=None):
        n = len(self.lb_gejala.curselection())
        self.lbl_terpilih.configure(text=f"Terpilih: {n} gejala")

    def _select_all_gejala(self):
        self.lb_gejala.select_set(0, END)
        self._on_listbox_change()

    def _clear_gejala(self):
        self.lb_gejala.selection_clear(0, END)
        self._on_listbox_change()

    def _get_selected_gejala_ids(self) -> list[int]:
        """Kembalikan list id gejala yang dipilih di listbox."""
        indices = self.lb_gejala.curselection()
        return [self._gejala_map[self._gejala_labels[i]] for i in indices]

    def _set_selected_gejala_ids(self, id_list: list[int]):
        """Pilih baris listbox yang id-nya ada di id_list."""
        self.lb_gejala.selection_clear(0, END)
        id_set = set(id_list)
        for idx, label in enumerate(self._gejala_labels):
            if self._gejala_map.get(label) in id_set:
                self.lb_gejala.select_set(idx)
        self._on_listbox_change()

    # ─────────────────────────────────────────────────────────────────────────
    # Reload data combo & listbox
    # ─────────────────────────────────────────────────────────────────────────
    def _reload_combos(self):
        penyakit_list = db.get_all_penyakit()
        gejala_list   = db.get_all_gejala()

        self._penyakit_map = {
            f"[{p['kode']}] {p['nama']}": p["id"]
            for p in penyakit_list
        }
        self.cmb_penyakit["values"] = list(self._penyakit_map.keys())

        self._gejala_map    = {}
        self._gejala_labels = []
        self.lb_gejala.delete(0, END)

        for g in gejala_list:
            label = f"[{g['kode']}] {g['nama']}"
            self._gejala_labels.append(label)
            self._gejala_map[label] = g["id"]
            self.lb_gejala.insert(END, label)

    # ─────────────────────────────────────────────────────────────────────────
    # Load tabel
    # ─────────────────────────────────────────────────────────────────────────
    def _load_data(self):
        for row in self.tree.get_children():
            self.tree.delete(row)

        for r in db.get_all_rules():
            self.tree.insert("", END, iid=str(r["id"]),
                             values=(r["nama_penyakit"],
                                     r["nama_gejala"],
                                     r["nilai_cf"]))

    # ─────────────────────────────────────────────────────────────────────────
    # Saat baris tabel dipilih → isi form
    # ─────────────────────────────────────────────────────────────────────────
    def _on_select(self, _event=None):
        sel = self.tree.selection()
        if not sel:
            return

        rule_id = int(sel[0])
        self._selected_id = rule_id

        item = self.tree.item(sel[0])
        vals = item["values"]
        nama_penyakit = vals[0]
        cf_val        = vals[2]

        # Set combobox penyakit
        p_key = next((k for k in self._penyakit_map if nama_penyakit in k), "")
        self.cmb_penyakit.set(p_key)

        # Set CF
        self.ent_cf.delete(0, END)
        self.ent_cf.insert(0, str(cf_val))

        # Set listbox gejala — ambil dari DB karena tabel hanya tampilkan nama gabungan
        try:
            import sqlite3
            conn = db.get_connection()
            rows = conn.execute(
                """SELECT gejala_id FROM rule_detail WHERE rule_id = ?""",
                (rule_id,)
            ).fetchall()
            conn.close()
            gejala_ids = [r["gejala_id"] for r in rows]
        except Exception:
            gejala_ids = []

        self._set_selected_gejala_ids(gejala_ids)

    # ─────────────────────────────────────────────────────────────────────────
    def _reset_form(self):
        self._selected_id = None
        self.cmb_penyakit.set("")
        self._clear_gejala()
        self.ent_cf.delete(0, END)
        self.tree.selection_remove(self.tree.selection())

    def _validate(self, pid, gejala_ids, cf_str) -> bool:
        if not pid:
            Messagebox.show_warning("Pilih penyakit terlebih dahulu!", parent=self)
            return False
        if not gejala_ids:
            Messagebox.show_warning("Pilih minimal 1 gejala!", parent=self)
            return False
        try:
            cf = float(cf_str)
            if not (0 <= cf <= 1):
                raise ValueError
        except ValueError:
            Messagebox.show_warning("Nilai CF harus angka antara 0 dan 1!", parent=self)
            return False
        return True

    # ─────────────────────────────────────────────────────────────────────────
    # CRUD
    # ─────────────────────────────────────────────────────────────────────────
    def _tambah(self):
        p_key      = self.cmb_penyakit.get()
        pid        = self._penyakit_map.get(p_key)
        gejala_ids = self._get_selected_gejala_ids()
        cf_str     = self.ent_cf.get().strip()

        if not self._validate(pid, gejala_ids, cf_str):
            return
        try:
            db.insert_rule(pid, gejala_ids, float(cf_str))
            Messagebox.show_info(
                f"Rule berhasil ditambahkan dengan {len(gejala_ids)} gejala.",
                parent=self)
            self._reset_form()
            self._load_data()
        except Exception as e:
            Messagebox.show_error(f"Gagal menambah rule:\n{e}", parent=self)

    def _ubah(self):
        if not self._selected_id:
            Messagebox.show_warning("Pilih rule yang ingin diubah!", parent=self)
            return
        p_key      = self.cmb_penyakit.get()
        pid        = self._penyakit_map.get(p_key)
        gejala_ids = self._get_selected_gejala_ids()
        cf_str     = self.ent_cf.get().strip()

        if not self._validate(pid, gejala_ids, cf_str):
            return
        try:
            db.update_rule(self._selected_id, pid, gejala_ids, float(cf_str))
            Messagebox.show_info(
                f"Rule berhasil diperbarui dengan {len(gejala_ids)} gejala.",
                parent=self)
            self._reset_form()
            self._load_data()
        except Exception as e:
            Messagebox.show_error(f"Gagal memperbarui rule:\n{e}", parent=self)

    def _hapus(self):
        if not self._selected_id:
            Messagebox.show_warning("Pilih rule yang ingin dihapus!", parent=self)
            return
        confirm = Messagebox.yesno("Hapus rule ini?", parent=self)
        if confirm == "Yes":
            db.delete_rule(self._selected_id)
            self._reset_form()
            self._load_data()

    def _cetak_laporan(self):
        from views.cetak_laporan_admin import cetak_laporan_admin_pdf
        data = db.get_all_rules()
        headers = ["No", "Penyakit", "Gejala", "CF"]
        rows = []
        for i, r_row in enumerate(data, 1):
            r = dict(r_row)
            g_str = r.get("gejala_str") or r.get("gejala_list") or ""
            if isinstance(g_str, list):
                g_str = ", ".join(g_str)
            # wrap or limit long symptom strings
            if len(g_str) > 100: g_str = g_str[:97] + "..."
            rows.append([str(i), r.get("nama_penyakit", ""), g_str, str(r.get("cf", 0))])
            
        cetak_laporan_admin_pdf(self.winfo_toplevel(), "LAPORAN DATA RULE (ATURAN)", headers, rows)

    def refresh(self):
        self._reload_combos()
        self._load_data()
