"""
views/hasil_diagnosis.py - Halaman Hasil Diagnosis
Menampilkan hasil fuzzy + faktor pendukung (riwayat ortu & imunisasi)
"""

import json
import datetime
import tkinter as tk
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from ttkbootstrap.dialogs import Messagebox
import database as db
import fuzzy as fz
from views.cetak_laporan import cetak_laporan


def _row(obj):
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return obj
    return dict(obj)


class HasilDiagnosisPage(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self._data: dict = {}
        self._sudah_disimpan = False
        self._build_shell()

    # ── Kerangka tetap UI ─────────────────────────────────────────────────────
    def _build_shell(self):
        header = ttk.Frame(self, bootstyle="success")
        header.pack(fill=X)
        inner_h = ttk.Frame(header, bootstyle="success")
        inner_h.pack(fill=X, padx=20, pady=12)

        ttk.Label(inner_h, text="Hasil Diagnosis",
                  font=("Segoe UI", 16, "bold"),
                  bootstyle="inverse-success").pack(side=LEFT)

        ttk.Button(inner_h, text="  Kembali",
                   bootstyle="light",
                   command=lambda: self.controller.show_page("InputGejala")
                   ).pack(side=RIGHT)

        ttk.Button(inner_h, text="  Cetak / Simpan Laporan",
                   bootstyle="warning",
                   command=self._cetak
                   ).pack(side=RIGHT, padx=(0, 8))

        ttk.Button(inner_h, text="  Simpan ke Riwayat",
                   bootstyle="info",
                   command=self._simpan_manual
                   ).pack(side=RIGHT, padx=(0, 8))

        self.content_frame = ttk.Frame(self)
        self.content_frame.pack(fill=BOTH, expand=True)

    # ── Render hasil ──────────────────────────────────────────────────────────
    def _render(self):
        for w in self.content_frame.winfo_children():
            w.destroy()

        hasil_list = self._data.get("hasil", [])
        gejala_ids = self._data.get("gejala_ids", [])

        if not hasil_list:
            ttk.Label(
                self.content_frame,
                text="Tidak ada penyakit yang cocok dengan gejala yang dipilih.",
                font=("Segoe UI", 12),
            ).pack(expand=True, pady=40)
            return

        canvas = tk.Canvas(self.content_frame, highlightthickness=0)
        sb = ttk.Scrollbar(self.content_frame, orient=VERTICAL,
                            command=canvas.yview, bootstyle="round")
        inner = ttk.Frame(canvas)
        inner.bind("<Configure>",
                   lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=inner, anchor=NW)
        canvas.configure(yscrollcommand=sb.set)
        canvas.pack(side=LEFT, fill=BOTH, expand=True)
        sb.pack(side=RIGHT, fill=Y)
        canvas.bind_all("<MouseWheel>",
                        lambda e: canvas.yview_scroll(-1 * (e.delta // 120), "units"))

        # ── Info pasien ───────────────────────────────────────────────────────
        nama     = self._data.get("nama_pasien", "")
        umur     = self._data.get("umur_pasien", "")
        jk       = self._data.get("jenis_kelamin", "")
        if nama or umur or jk:
            pasien_frame = ttk.Frame(inner, bootstyle="primary")
            pasien_frame.pack(fill=X, padx=20, pady=(15, 0))
            teks = (f"  Pasien: {nama or '-'}"
                    f"   |   Umur: {umur or '-'} bulan"
                    f"   |   Jenis Kelamin: {jk or '-'}")
            ttk.Label(pasien_frame, text=teks,
                      font=("Segoe UI", 9),
                      bootstyle="inverse-primary").pack(anchor=W, padx=8, pady=5)

        # ── Gejala yang dipilih ───────────────────────────────────────────────
        gejala_header = ttk.Frame(inner, bootstyle="secondary")
        gejala_header.pack(fill=X, padx=20, pady=(10, 0))
        ttk.Label(gejala_header, text="  Gejala yang Dipilih",
                  font=("Segoe UI", 10, "bold"),
                  bootstyle="inverse-secondary").pack(anchor=W, padx=8, pady=5)

        gejala_body = ttk.Frame(inner)
        gejala_body.pack(fill=X, padx=20, pady=(0, 10))
        all_gejala = {g["id"]: _row(g) for g in db.get_all_gejala()}
        gejala_terpilih = [all_gejala[gid] for gid in gejala_ids if gid in all_gejala]
        cols = 2
        for idx, g in enumerate(gejala_terpilih):
            r, c = divmod(idx, cols)
            ttk.Label(gejala_body, text=f"  [{g['kode']}] {g['nama']}",
                      font=("Segoe UI", 9)).grid(row=r, column=c, sticky=W, padx=6, pady=2)

        # ── Diagnosa Utama (Fuzzy Sugeno) ─────────────────────────────────────
        diag_header = ttk.Frame(inner, bootstyle="success")
        diag_header.pack(fill=X, padx=20, pady=(10, 0))
        ttk.Label(diag_header, text="  Diagnosa Utama  (Fuzzy Sugeno)",
                  font=("Segoe UI", 10, "bold"),
                  bootstyle="inverse-success").pack(anchor=W, padx=8, pady=5)

        for rank, h in enumerate(hasil_list[:5], 1):
            self._diagnosis_card(inner, rank, h)

        # ── Faktor Pendukung ──────────────────────────────────────────────────
        self._render_faktor_pendukung(inner)

        # ── Detail Penyakit #1 ────────────────────────────────────────────────
        if hasil_list:
            top = hasil_list[0]
            penyakit = _row(db.get_penyakit_by_id(top.penyakit_id))
            if penyakit:
                rek_header = ttk.Frame(inner, bootstyle="warning")
                rek_header.pack(fill=X, padx=20, pady=(12, 0))
                ttk.Label(rek_header,
                          text=f"  Rekomendasi: {penyakit['nama']}",
                          font=("Segoe UI", 10, "bold"),
                          bootstyle="inverse-warning").pack(anchor=W, padx=8, pady=5)

                rek_body = ttk.Frame(inner)
                rek_body.pack(fill=X, padx=20, pady=(0, 20))

                ttk.Label(rek_body, text="Deskripsi:",
                          font=("Segoe UI", 10, "bold")).pack(anchor=W, padx=10, pady=(8, 0))
                ttk.Label(rek_body, text=penyakit.get("deskripsi") or "-",
                          font=("Segoe UI", 9),
                          wraplength=700, justify=LEFT).pack(anchor=W, padx=10, pady=(2, 8))

                ttk.Label(rek_body, text="Solusi / Penanganan:",
                          font=("Segoe UI", 10, "bold")).pack(anchor=W, padx=10)
                ttk.Label(rek_body, text=penyakit.get("solusi") or "-",
                          font=("Segoe UI", 9),
                          wraplength=700, justify=LEFT).pack(anchor=W, padx=10, pady=(2, 12))

        # ── Disclaimer ────────────────────────────────────────────────────────
        ttk.Label(inner,
                  text="Hasil ini hanya sebagai referensi awal. Konsultasikan dengan dokter untuk diagnosis yang akurat.",
                  font=("Segoe UI", 8, "italic"),
                  foreground="#888", wraplength=700,
                  ).pack(pady=(0, 20), padx=20)

    # ── Faktor Pendukung Section ──────────────────────────────────────────────
    def _render_faktor_pendukung(self, parent):
        riwayat_ortu     = self._data.get("riwayat_ortu", [])
        status_imunisasi = self._data.get("status_imunisasi", {})

        faktor_items = []

        # Dari riwayat orang tua
        for nama in riwayat_ortu:
            if nama and nama != "Tidak Ada":
                faktor_items.append(("ortu", f"Orang tua memiliki riwayat {nama}"))

        # Dari status imunisasi belum
        for nama_imu, status in status_imunisasi.items():
            if status == "Belum":
                faktor_items.append(("imu", f"Imunisasi {nama_imu} belum lengkap"))

        # Hanya tampilkan section jika ada faktor
        if not faktor_items and not riwayat_ortu and not status_imunisasi:
            return

        fhdr = ttk.Frame(parent, bootstyle="info")
        fhdr.pack(fill=X, padx=20, pady=(10, 0))
        ttk.Label(fhdr, text="  Faktor Pendukung",
                  font=("Segoe UI", 10, "bold"),
                  bootstyle="inverse-info").pack(anchor=W, padx=8, pady=5)

        fbody = ttk.Frame(parent)
        fbody.pack(fill=X, padx=20, pady=(4, 0))

        if faktor_items:
            for kind, teks in faktor_items:
                icon = "⚕" if kind == "ortu" else "💉"
                row = ttk.Frame(fbody)
                row.pack(fill=X, padx=10, pady=2)
                ttk.Label(row, text=f"  {icon}  {teks}",
                          font=("Segoe UI", 9),
                          foreground="#0d6efd").pack(side=LEFT)
        else:
            ttk.Label(fbody,
                      text="  ✓  Tidak ada faktor risiko tambahan yang teridentifikasi.",
                      font=("Segoe UI", 9),
                      foreground="#198754").pack(anchor=W, padx=10, pady=4)

        # Status imunisasi lengkap
        if status_imunisasi:
            imu_sudah = [n for n, s in status_imunisasi.items() if s == "Sudah"]
            if imu_sudah:
                ttk.Label(fbody,
                          text=f"  ✓  Imunisasi sudah: {', '.join(imu_sudah)}",
                          font=("Segoe UI", 9),
                          foreground="#198754").pack(anchor=W, padx=10, pady=2)

        # Catatan
        note_frame = ttk.Frame(parent, bootstyle="light")
        note_frame.pack(fill=X, padx=20, pady=(6, 0))
        ttk.Label(note_frame,
                  text='  ⓘ  Catatan: Riwayat penyakit keluarga dan status imunisasi digunakan sebagai '
                       'faktor pendukung analisis, bukan sebagai penentu utama diagnosa.',
                  font=("Segoe UI", 8, "italic"),
                  foreground="#555",
                  wraplength=700, justify=LEFT).pack(anchor=W, padx=8, pady=6)

    # ── Kartu diagnosis ───────────────────────────────────────────────────────
    def _diagnosis_card(self, parent, rank: int, h):
        label = fz.label_kepastian(h.persentase)
        styles = {
            "Sangat Tinggi": ("danger",    "[!!]"),
            "Tinggi":        ("warning",   "[!] "),
            "Sedang":        ("info",      "[~] "),
            "Rendah":        ("success",   "[v] "),
            "Sangat Rendah": ("secondary", "[-] "),
        }
        style, icon = styles.get(label, ("secondary", "[-] "))

        card = ttk.Frame(parent, bootstyle=style)
        card.pack(fill=X, padx=20, pady=(4, 0))
        ttk.Label(card, text=f"  {rank}. {icon}  {h.nama_penyakit}",
                  font=("Segoe UI", 11, "bold"),
                  bootstyle=f"inverse-{style}").pack(side=LEFT, pady=8)
        ttk.Label(card, text=f"{h.persentase:.1f}%  |  {label}  ",
                  font=("Segoe UI", 10, "bold"),
                  bootstyle=f"inverse-{style}").pack(side=RIGHT, pady=8)

        pb_frame = ttk.Frame(parent)
        pb_frame.pack(fill=X, padx=20)
        ttk.Progressbar(pb_frame, value=h.persentase,
                        bootstyle=f"{style}-striped",
                        maximum=100).pack(fill=X, pady=(0, 3))

    # ── set_data ──────────────────────────────────────────────────────────────
    def set_data(self, data: dict):
        self._data = data
        self._sudah_disimpan = False

    # ── Simpan manual ─────────────────────────────────────────────────────────
    def _simpan_manual(self):
        if not self._data.get("hasil"):
            Messagebox.show_warning(
                title="Belum Ada Data",
                message="Lakukan diagnosis terlebih dahulu.",
                parent=self)
            return
        if getattr(self, "_sudah_disimpan", False):
            konfirm = Messagebox.yesno(
                title="Sudah Tersimpan",
                message="Diagnosis ini sudah pernah disimpan ke riwayat.\nSimpan lagi?",
                parent=self)
            if konfirm != "Yes":
                return
        self._do_simpan_riwayat()

    def _do_simpan_riwayat(self):
        hasil_list       = self._data.get("hasil", [])
        gejala_ids       = self._data.get("gejala_ids", [])
        nama             = self._data.get("nama_pasien", "")
        umur             = self._data.get("umur_pasien", "")
        jk               = self._data.get("jenis_kelamin", "")
        riwayat_ortu     = self._data.get("riwayat_ortu", [])
        status_imunisasi = self._data.get("status_imunisasi", {})
        try:
            tanggal = datetime.datetime.now().strftime("%d %B %Y, %H:%M WIB")
            hasil_serial = [
                {
                    "penyakit_id":   h.penyakit_id,
                    "nama_penyakit": h.nama_penyakit,
                    "persentase":    h.persentase,
                }
                for h in hasil_list
            ]
            db.insert_riwayat(
                tanggal               = tanggal,
                nama_pasien           = nama,
                umur_pasien           = umur,
                jenis_kelamin         = jk,
                gejala_ids_json       = json.dumps(gejala_ids),
                riwayat_ortu_json     = json.dumps(riwayat_ortu),
                status_imunisasi_json = json.dumps(status_imunisasi),
                hasil_json            = json.dumps(hasil_serial),
            )
            self._sudah_disimpan = True
            Messagebox.show_info(
                "Hasil diagnosis berhasil disimpan ke riwayat.",
                title="Tersimpan", parent=self)
        except Exception as e:
            Messagebox.show_error(
                f"Gagal menyimpan riwayat:\n{e}",
                title="Error", parent=self)

    def refresh(self):
        self._render()

    # ── Cetak laporan ─────────────────────────────────────────────────────────
    def _cetak(self):
        if not self._data.get("hasil"):
            Messagebox.show_warning(
                title="Belum Ada Data",
                message="Lakukan diagnosis terlebih dahulu sebelum mencetak laporan.",
                parent=self)
            return
        cetak_laporan(
            parent_window = self.winfo_toplevel(),
            data          = self._data,
            nama_pasien   = self._data.get("nama_pasien", ""),
            umur          = self._data.get("umur_pasien", ""),
        )
