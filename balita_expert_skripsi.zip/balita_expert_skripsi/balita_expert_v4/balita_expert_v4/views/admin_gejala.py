"""
views/admin_gejala.py - Admin Panel: CRUD Data Gejala
"""

import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from ttkbootstrap.dialogs import Messagebox
import database as db


class AdminGejalaPage(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self._selected_id = None
        self._build_ui()

    def _build_ui(self):
        # ================= HEADER =================
        hdr = ttk.Frame(self, bootstyle="warning", padding=(20, 10))
        hdr.pack(fill=X)

        ttk.Label(
            hdr,
            text="📋 Admin – Data Gejala",
            font=("Segoe UI", 14, "bold"),
            bootstyle="inverse-warning"
        ).pack(side=LEFT)

        # ================= BODY =================
        body = ttk.Frame(self, padding=15)
        body.pack(fill=BOTH, expand=True)

        body.columnconfigure(0, weight=3)
        body.columnconfigure(1, weight=2)
        body.rowconfigure(0, weight=1)

        # ================= KIRI: TABEL =================
        left_frame = ttk.Frame(body)
        left_frame.grid(row=0, column=0, sticky=NSEW, padx=(0, 10))

        ttk.Label(
            left_frame,
            text="📋 Daftar Gejala",
            font=("Segoe UI", 11, "bold")
        ).pack(anchor=W, pady=(0, 8))

        table_box = ttk.Frame(left_frame)
        table_box.pack(fill=BOTH, expand=True)

        cols = ("Kode", "Nama Gejala", "Bobot")

        self.tree = ttk.Treeview(
            table_box,
            columns=cols,
            show="headings",
            bootstyle="warning",
            selectmode="browse",
            height=18
        )

        for col in cols:
            self.tree.heading(col, text=col, anchor=W)

        self.tree.column("Kode", width=80, anchor=W)
        self.tree.column("Nama Gejala", width=250, anchor=W)
        self.tree.column("Bobot", width=80, anchor=W)

        vsb = ttk.Scrollbar(
            table_box,
            orient=VERTICAL,
            command=self.tree.yview,
            bootstyle="round"
        )

        self.tree.configure(yscrollcommand=vsb.set)

        self.tree.pack(side=LEFT, fill=BOTH, expand=True)
        vsb.pack(side=RIGHT, fill=Y)

        self.tree.bind("<<TreeviewSelect>>", self._on_select)

        # ================= KANAN: FORM =================
        form = ttk.Frame(body, padding=15, bootstyle="light")
        form.grid(row=0, column=1, sticky=NSEW)

        ttk.Label(
            form,
            text="📝 Form Gejala",
            font=("Segoe UI", 11, "bold")
        ).pack(anchor=W, pady=(0, 10))

        fields = [
            ("Kode*", "ent_kode"),
            ("Nama*", "ent_nama"),
            ("Bobot (0–1)*", "ent_bobot")
        ]

        for label, attr in fields:
            ttk.Label(
                form,
                text=label,
                font=("Segoe UI", 9, "bold")
            ).pack(anchor=W, pady=(8, 2))

            ent = ttk.Entry(form)
            ent.pack(fill=X)

            setattr(self, attr, ent)

        ttk.Label(
            form,
            text="Bobot: 1.0 = sangat signifikan, 0.5 = sedang",
            font=("Segoe UI", 8),
            foreground="#888"
        ).pack(anchor=W, pady=(6, 0))

        # ================= BUTTON =================
        btn = ttk.Frame(form, padding=(0, 15))
        btn.pack(fill=X)

        ttk.Button(
            btn,
            text="➕ Tambah",
            bootstyle="success",
            command=self._tambah
        ).pack(side=LEFT, padx=(0, 5))

        ttk.Button(
            btn,
            text="✏ Ubah",
            bootstyle="warning",
            command=self._ubah
        ).pack(side=LEFT, padx=5)

        ttk.Button(
            btn,
            text="🗑 Hapus",
            bootstyle="danger",
            command=self._hapus
        ).pack(side=LEFT, padx=5)

        ttk.Button(
            btn,
            text="🔄 Reset",
            bootstyle="secondary",
            command=self._reset_form
        ).pack(side=RIGHT)

        ttk.Button(
            btn,
            text="🖨 Cetak Laporan",
            bootstyle="primary",
            command=self._cetak_laporan
        ).pack(side=RIGHT, padx=(0, 5))

        self._load_data()

    # ================= DATA =================
    def _load_data(self):
        self.tree.delete(*self.tree.get_children())

        for g in db.get_all_gejala():
            self.tree.insert(
                "",
                END,
                iid=str(g["id"]),
                values=(g["kode"], g["nama"], g["bobot"])
            )

    def _on_select(self, _event=None):
        selected = self.tree.selection()

        if not selected:
            return

        gid = int(selected[0])
        self._selected_id = gid

        g = db.get_gejala_by_id(gid)
        if not g:
            return

        self.ent_kode.delete(0, END)
        self.ent_kode.insert(0, g["kode"])

        self.ent_nama.delete(0, END)
        self.ent_nama.insert(0, g["nama"])

        self.ent_bobot.delete(0, END)
        self.ent_bobot.insert(0, str(g["bobot"]))

    def _get_form(self):
        return (
            self.ent_kode.get().strip(),
            self.ent_nama.get().strip(),
            self.ent_bobot.get().strip()
        )

    def _reset_form(self):
        self._selected_id = None

        for widget in (self.ent_kode, self.ent_nama, self.ent_bobot):
            widget.delete(0, END)

        self.tree.selection_remove(self.tree.selection())

    def _validate(self, kode, nama, bobot_str):
        if not kode or not nama or not bobot_str:
            Messagebox.show_warning(
                "Semua field wajib diisi!",
                parent=self
            )
            return False

        try:
            bobot = float(bobot_str)

            if not (0 <= bobot <= 1):
                raise ValueError

        except ValueError:
            Messagebox.show_warning(
                "Bobot harus angka antara 0 dan 1!",
                parent=self
            )
            return False

        return True

    # ================= CRUD =================
    def _tambah(self):
        kode, nama, bobot = self._get_form()

        if not self._validate(kode, nama, bobot):
            return

        try:
            db.insert_gejala(kode, nama, float(bobot))
            Messagebox.show_info("Gejala berhasil ditambahkan.", parent=self)
            self._reset_form()
            self._load_data()

        except Exception as e:
            Messagebox.show_error(f"Gagal:\n{e}", parent=self)

    def _ubah(self):
        if not self._selected_id:
            Messagebox.show_warning(
                "Pilih gejala yang ingin diubah!",
                parent=self
            )
            return

        kode, nama, bobot = self._get_form()

        if not self._validate(kode, nama, bobot):
            return

        try:
            db.update_gejala(self._selected_id, kode, nama, float(bobot))
            Messagebox.show_info("Gejala berhasil diperbarui.", parent=self)
            self._reset_form()
            self._load_data()

        except Exception as e:
            Messagebox.show_error(f"Gagal:\n{e}", parent=self)

    def _hapus(self):
        if not self._selected_id:
            Messagebox.show_warning(
                "Pilih gejala yang ingin dihapus!",
                parent=self
            )
            return

        confirm = Messagebox.yesno(
            "Hapus gejala ini?",
            parent=self
        )

        if confirm == "Yes":
            db.delete_gejala(self._selected_id)
            self._reset_form()
            self._load_data()

    def _cetak_laporan(self):
        from views.cetak_laporan_admin import cetak_laporan_admin_pdf
        data = db.get_all_gejala()
        headers = ["No", "Kode", "Nama Gejala", "Bobot"]
        rows = []
        for i, g_row in enumerate(data, 1):
            g = dict(g_row)
            rows.append([str(i), g["kode"], g["nama"], str(g.get("bobot", 0))])
        
        cetak_laporan_admin_pdf(self.winfo_toplevel(), "LAPORAN DATA GEJALA", headers, rows)

    def refresh(self):
        self._load_data()