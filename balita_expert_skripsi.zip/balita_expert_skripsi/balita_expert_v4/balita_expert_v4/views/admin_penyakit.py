"""
views/admin_penyakit.py - Admin Panel: CRUD Data Penyakit
"""

import tkinter as tk
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from ttkbootstrap.dialogs import Messagebox
import database as db


class AdminPenyakitPage(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self._selected_id = None
        self._build_ui()

    def _build_ui(self):
        # ================= HEADER =================
        hdr = ttk.Frame(self, bootstyle="danger", padding=(20, 10))
        hdr.pack(fill=X)

        ttk.Label(
            hdr,
            text="🦠 Admin – Data Penyakit",
            font=("Segoe UI", 14, "bold"),
            bootstyle="inverse-danger"
        ).pack(side=LEFT)

        # ================= BODY =================
        body = ttk.Frame(self, padding=15)
        body.pack(fill=BOTH, expand=True)

        # Layout kiri-kanan pakai grid
        body.columnconfigure(0, weight=3)
        body.columnconfigure(1, weight=2)
        body.rowconfigure(0, weight=1)

        # ================= KIRI: TABEL =================
        left_frame = ttk.Frame(body)
        left_frame.grid(row=0, column=0, sticky=NSEW, padx=(0, 10))

        ttk.Label(
            left_frame,
            text="📋 Daftar Penyakit",
            font=("Segoe UI", 11, "bold")
        ).pack(anchor=W, pady=(0, 8))

        table_box = ttk.Frame(left_frame)
        table_box.pack(fill=BOTH, expand=True)

        cols = ("Kode", "Nama Penyakit")
        self.tree = ttk.Treeview(
            table_box,
            columns=cols,
            show="headings",
            bootstyle="danger",
            selectmode="browse",
            height=18
        )

        self.tree.heading("Kode", text="Kode", anchor=W)
        self.tree.heading("Nama Penyakit", text="Nama Penyakit", anchor=W)

        self.tree.column("Kode", width=80, anchor=W)
        self.tree.column("Nama Penyakit", width=250, anchor=W)

        vsb = ttk.Scrollbar(
            table_box,
            orient=VERTICAL,
            command=self.tree.yview,
            bootstyle="round"
        )

        self.tree.configure(yscrollcommand=vsb.set)

        self.tree.pack(side=LEFT, fill=BOTH, expand=True)
        vsb.pack(side=RIGHT, fill=Y)

        self.tree.bind("<<TreeviewSelect>>", self._on_select)

        # ================= KANAN: FORM =================
        form = ttk.Frame(body, padding=15, bootstyle="light")
        form.grid(row=0, column=1, sticky=NSEW)

        ttk.Label(
            form,
            text="📝 Form Penyakit",
            font=("Segoe UI", 11, "bold")
        ).pack(anchor=W, pady=(0, 10))

        fields = [
            ("Kode*", "ent_kode"),
            ("Nama*", "ent_nama"),
            ("Deskripsi", "ent_desc"),
            ("Solusi", "ent_sol"),
        ]

        for label, attr in fields:
            ttk.Label(
                form,
                text=label,
                font=("Segoe UI", 9, "bold")
            ).pack(anchor=W, pady=(6, 2))

            if attr in ("ent_desc", "ent_sol"):
                txt = tk.Text(
                    form,
                    height=4,
                    font=("Segoe UI", 9),
                    relief="solid",
                    bd=1
                )
                txt.pack(fill=X)
                setattr(self, attr, txt)
            else:
                ent = ttk.Entry(form)
                ent.pack(fill=X)
                setattr(self, attr, ent)

        # ================= BUTTON =================
        btn = ttk.Frame(form, padding=(0, 15))
        btn.pack(fill=X)

        ttk.Button(
            btn,
            text="➕ Tambah",
            bootstyle="success",
            command=self._tambah
        ).pack(side=LEFT, padx=(0, 5))

        ttk.Button(
            btn,
            text="✏ Ubah",
            bootstyle="warning",
            command=self._ubah
        ).pack(side=LEFT, padx=5)

        ttk.Button(
            btn,
            text="🗑 Hapus",
            bootstyle="danger",
            command=self._hapus
        ).pack(side=LEFT, padx=5)

        ttk.Button(
            btn,
            text="🔄 Reset",
            bootstyle="secondary",
            command=self._reset_form
        ).pack(side=RIGHT)

        ttk.Button(
            btn,
            text="🖨 Cetak Laporan",
            bootstyle="primary",
            command=self._cetak_laporan
        ).pack(side=RIGHT, padx=(0, 5))

        self._load_data()

    # ================= DATA =================
    def _load_data(self):
        self.tree.delete(*self.tree.get_children())

        for p in db.get_all_penyakit():
            self.tree.insert(
                "",
                END,
                iid=str(p["id"]),
                values=(p["kode"], p["nama"])
            )

    def _on_select(self, _event=None):
        selected = self.tree.selection()
        if not selected:
            return

        pid = int(selected[0])
        self._selected_id = pid

        p = db.get_penyakit_by_id(pid)
        if not p:
            return

        self._set_form(
            p["kode"],
            p["nama"],
            p["deskripsi"] or "",
            p["solusi"] or ""
        )

    def _get_form(self):
        kode = self.ent_kode.get().strip()
        nama = self.ent_nama.get().strip()
        desc = self.ent_desc.get("1.0", END).strip()
        sol = self.ent_sol.get("1.0", END).strip()
        return kode, nama, desc, sol

    def _set_form(self, kode, nama, desc, sol):
        self.ent_kode.delete(0, END)
        self.ent_kode.insert(0, kode)

        self.ent_nama.delete(0, END)
        self.ent_nama.insert(0, nama)

        self.ent_desc.delete("1.0", END)
        self.ent_desc.insert("1.0", desc)

        self.ent_sol.delete("1.0", END)
        self.ent_sol.insert("1.0", sol)

    def _reset_form(self):
        self._selected_id = None
        self._set_form("", "", "", "")
        self.tree.selection_remove(self.tree.selection())

    def _validate(self, kode, nama):
        if not kode or not nama:
            Messagebox.show_warning(
                "Kode dan Nama wajib diisi!",
                parent=self
            )
            return False
        return True

    # ================= CRUD =================
    def _tambah(self):
        kode, nama, desc, sol = self._get_form()

        if not self._validate(kode, nama):
            return

        try:
            db.insert_penyakit(kode, nama, desc, sol)
            Messagebox.show_info("Data berhasil ditambahkan.", parent=self)
            self._reset_form()
            self._load_data()
        except Exception as e:
            Messagebox.show_error(f"Gagal menyimpan:\n{e}", parent=self)

    def _ubah(self):
        if not self._selected_id:
            Messagebox.show_warning(
                "Pilih data yang ingin diubah!",
                parent=self
            )
            return

        kode, nama, desc, sol = self._get_form()

        if not self._validate(kode, nama):
            return

        try:
            db.update_penyakit(self._selected_id, kode, nama, desc, sol)
            Messagebox.show_info("Data berhasil diperbarui.", parent=self)
            self._reset_form()
            self._load_data()
        except Exception as e:
            Messagebox.show_error(f"Gagal update:\n{e}", parent=self)

    def _hapus(self):
        if not self._selected_id:
            Messagebox.show_warning(
                "Pilih data yang ingin dihapus!",
                parent=self
            )
            return

        confirm = Messagebox.yesno(
            "Hapus penyakit ini? Semua rule terkait akan terhapus.",
            parent=self
        )

        if confirm == "Yes":
            db.delete_penyakit(self._selected_id)
            self._reset_form()
            self._load_data()

    def _cetak_laporan(self):
        from views.cetak_laporan_admin import cetak_laporan_admin_pdf
        data = db.get_all_penyakit()
        headers = ["No", "Kode", "Nama Penyakit", "Deskripsi", "Solusi"]
        rows = []
        for i, p_row in enumerate(data, 1):
            p = dict(p_row)
            desc = p.get("deskripsi") or "-"
            sol = p.get("solusi") or "-"
            # Limit long texts in PDF table to avoid huge rows if necessary
            if len(desc) > 80: desc = desc[:77] + "..."
            if len(sol) > 80: sol = sol[:77] + "..."
            rows.append([str(i), p["kode"], p["nama"], desc, sol])
        
        cetak_laporan_admin_pdf(self.winfo_toplevel(), "LAPORAN DATA PENYAKIT", headers, rows)

    def refresh(self):
        self._load_data()