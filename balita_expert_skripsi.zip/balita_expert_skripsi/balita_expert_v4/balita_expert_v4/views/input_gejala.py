"""
views/input_gejala.py - Halaman Input Gejala (Wizard 4 Tahap)
Tahap 1: Data Balita
Tahap 2: Gejala
Tahap 3: Riwayat Penyakit Orang Tua
Tahap 4: Status Imunisasi
"""

import tkinter as tk
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from ttkbootstrap.dialogs import Messagebox
import database as db
import fuzzy as fz


class InputGejalaPage(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.check_vars: dict[int, tk.BooleanVar] = {}
        self.ortu_vars: dict[str, tk.BooleanVar] = {}
        self.imu_vars: dict[str, tk.StringVar] = {}
        self._current_step = 0
        self._steps_frames = []
        self._build_ui()

    # ─────────────────────────────────────────────────────────────────────────
    def _build_ui(self):
        # ── Header ───────────────────────────────────────────────────────────
        header = ttk.Frame(self, bootstyle="success")
        header.pack(fill=X)
        inner_h = ttk.Frame(header, bootstyle="success")
        inner_h.pack(fill=X, padx=20, pady=12)
        ttk.Label(inner_h, text="Diagnosa Penyakit Balita",
                  font=("Segoe UI", 16, "bold"),
                  bootstyle="inverse-success").pack(side=LEFT)

        # ── Wizard Step Indicator ─────────────────────────────────────────────
        self._step_bar = ttk.Frame(self)
        self._step_bar.pack(fill=X, padx=20, pady=(12, 0))
        self._step_labels = []
        step_names = ["Data Balita", "Gejala", "Riwayat Orang Tua", "Imunisasi"]
        for i, name in enumerate(step_names):
            col_frame = ttk.Frame(self._step_bar)
            col_frame.pack(side=LEFT, expand=True, fill=X)
            num_lbl = ttk.Label(col_frame, text=str(i + 1),
                                font=("Segoe UI", 12, "bold"),
                                width=3, anchor=CENTER)
            num_lbl.pack()
            txt_lbl = ttk.Label(col_frame, text=name,
                                font=("Segoe UI", 8), anchor=CENTER)
            txt_lbl.pack()
            self._step_labels.append((num_lbl, txt_lbl))
            if i < len(step_names) - 1:
                ttk.Label(self._step_bar, text="──",
                          foreground="#ccc").pack(side=LEFT)

        ttk.Separator(self).pack(fill=X, padx=20, pady=8)

        # ── Container untuk semua step ────────────────────────────────────────
        self._container = ttk.Frame(self)
        self._container.pack(fill=BOTH, expand=True)

        self._frame_step1 = ttk.Frame(self._container)
        self._frame_step2 = ttk.Frame(self._container)
        self._frame_step3 = ttk.Frame(self._container)
        self._frame_step4 = ttk.Frame(self._container)
        self._steps_frames = [
            self._frame_step1,
            self._frame_step2,
            self._frame_step3,
            self._frame_step4,
        ]

        self._build_step1(self._frame_step1)
        self._build_step2(self._frame_step2)
        self._build_step3(self._frame_step3)
        self._build_step4(self._frame_step4)

        # ── Footer navigasi ───────────────────────────────────────────────────
        footer = ttk.Frame(self)
        footer.pack(fill=X, padx=20, pady=10)

        self.btn_prev = ttk.Button(footer, text="◀  Sebelumnya",
                                   bootstyle="secondary-outline",
                                   command=self._prev_step)
        self.btn_prev.pack(side=LEFT)

        self.btn_next = ttk.Button(footer, text="Selanjutnya  ▶",
                                   bootstyle="success",
                                   command=self._next_step)
        self.btn_next.pack(side=RIGHT)

        self.btn_diagnosa = ttk.Button(footer, text="  Diagnosa Sekarang  ",
                                       bootstyle="success",
                                       command=self._diagnosa)
        self.btn_diagnosa.pack(side=RIGHT, padx=(0, 8))

        self._goto_step(0)

    # ─────────────────────────────────────────────────────────────────────────
    # STEP 1 – Data Balita
    # ─────────────────────────────────────────────────────────────────────────
    def _build_step1(self, parent):
        ttk.Label(parent, text="Data Identitas Balita",
                  font=("Segoe UI", 13, "bold")).pack(anchor=W, padx=30, pady=(20, 4))
        ttk.Label(parent,
                  text="Isi data balita untuk keperluan rekam medis dan laporan.",
                  font=("Segoe UI", 9), foreground="#666").pack(anchor=W, padx=30, pady=(0, 16))

        form = ttk.Labelframe(parent, text="Identitas Pasien", bootstyle="success", padding=20)
        form.pack(fill=X, padx=30, pady=(0, 10))

        # Nama
        ttk.Label(form, text="Nama Balita *",
                  font=("Segoe UI", 9, "bold")).grid(row=0, column=0, sticky=W, pady=8, padx=(0, 12))
        self.var_nama = tk.StringVar()
        ttk.Entry(form, textvariable=self.var_nama,
                  width=35, font=("Segoe UI", 9)).grid(row=0, column=1, sticky=W, pady=8)

        # Umur
        ttk.Label(form, text="Umur (bulan) *",
                  font=("Segoe UI", 9, "bold")).grid(row=1, column=0, sticky=W, pady=8, padx=(0, 12))
        self.var_umur = tk.StringVar()
        umur_frame = ttk.Frame(form)
        umur_frame.grid(row=1, column=1, sticky=W, pady=8)
        ttk.Entry(umur_frame, textvariable=self.var_umur,
                  width=10, font=("Segoe UI", 9)).pack(side=LEFT)
        ttk.Label(umur_frame, text="bulan  (0–60)",
                  font=("Segoe UI", 8), foreground="#888").pack(side=LEFT, padx=(8, 0))

        # Jenis Kelamin
        ttk.Label(form, text="Jenis Kelamin *",
                  font=("Segoe UI", 9, "bold")).grid(row=2, column=0, sticky=W, pady=8, padx=(0, 12))
        self.var_jk = tk.StringVar(value="Laki-laki")
        jk_frame = ttk.Frame(form)
        jk_frame.grid(row=2, column=1, sticky=W, pady=8)
        ttk.Radiobutton(jk_frame, text="Laki-laki", variable=self.var_jk,
                        value="Laki-laki", bootstyle="success").pack(side=LEFT, padx=(0, 16))
        ttk.Radiobutton(jk_frame, text="Perempuan", variable=self.var_jk,
                        value="Perempuan", bootstyle="success").pack(side=LEFT)

    # ─────────────────────────────────────────────────────────────────────────
    # STEP 2 – Gejala (existing, tidak diubah logika)
    # ─────────────────────────────────────────────────────────────────────────
    def _build_step2(self, parent):
        ttk.Label(parent, text="Pilih Gejala yang Dialami",
                  font=("Segoe UI", 13, "bold")).pack(anchor=W, padx=30, pady=(20, 4))
        ttk.Label(parent,
                  text="Centang semua gejala yang dialami balita saat ini.",
                  font=("Segoe UI", 9), foreground="#666").pack(anchor=W, padx=30, pady=(0, 10))

        action_bar = ttk.Frame(parent)
        action_bar.pack(fill=X, padx=30, pady=(0, 6))
        ttk.Button(action_bar, text="Pilih Semua", bootstyle="secondary-outline",
                   command=self._pilih_semua).pack(side=LEFT, padx=(0, 8))
        ttk.Button(action_bar, text="Hapus Semua", bootstyle="secondary-outline",
                   command=self._hapus_semua).pack(side=LEFT)

        ttk.Separator(parent).pack(fill=X, padx=20)

        body = ttk.Frame(parent)
        body.pack(fill=BOTH, expand=True, padx=20, pady=8)

        canvas = tk.Canvas(body, highlightthickness=0)
        scrollbar = ttk.Scrollbar(body, orient=VERTICAL,
                                  command=canvas.yview, bootstyle="round")
        self.inner_gejala = ttk.Frame(canvas)
        self.inner_gejala.bind("<Configure>",
                               lambda e: canvas.configure(
                                   scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self.inner_gejala, anchor=NW)
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side=LEFT, fill=BOTH, expand=True)
        scrollbar.pack(side=RIGHT, fill=Y)
        canvas.bind_all("<MouseWheel>",
                        lambda e: canvas.yview_scroll(-1 * (e.delta // 120), "units"))
        self._populate_gejala()

    def _populate_gejala(self):
        for w in self.inner_gejala.winfo_children():
            w.destroy()
        self.check_vars.clear()
        gejala_list = db.get_all_gejala()
        cols = 2
        for idx, g in enumerate(gejala_list):
            row, col = divmod(idx, cols)
            var = tk.BooleanVar(value=False)
            self.check_vars[g["id"]] = var
            frame = ttk.Frame(self.inner_gejala)
            frame.grid(row=row, column=col, sticky=W, padx=10, pady=2)
            cb = ttk.Checkbutton(frame,
                                 text=f"[{g['kode']}]  {g['nama']}",
                                 variable=var,
                                 bootstyle="success-round-toggle")
            cb.pack(side=LEFT)
            ttk.Label(frame, text=f"(bobot: {g['bobot']:.1f})",
                      font=("Segoe UI", 8), foreground="#888").pack(side=LEFT, padx=(8, 0))
        for c in range(cols):
            self.inner_gejala.columnconfigure(c, weight=1)

    def _pilih_semua(self):
        for var in self.check_vars.values():
            var.set(True)

    def _hapus_semua(self):
        for var in self.check_vars.values():
            var.set(False)

    # ─────────────────────────────────────────────────────────────────────────
    # STEP 3 – Riwayat Penyakit Orang Tua
    # ─────────────────────────────────────────────────────────────────────────
    def _build_step3(self, parent):
        ttk.Label(parent, text="Riwayat Penyakit Orang Tua",
                  font=("Segoe UI", 13, "bold")).pack(anchor=W, padx=30, pady=(20, 4))
        ttk.Label(parent,
                  text="Pilih penyakit yang pernah/sedang diderita oleh ayah atau ibu balita.\n"
                       "Data ini digunakan sebagai faktor pendukung, bukan penentu utama diagnosa.",
                  font=("Segoe UI", 9), foreground="#666",
                  justify=LEFT).pack(anchor=W, padx=30, pady=(0, 16))

        ortu_frame = ttk.Labelframe(parent, text="Riwayat Penyakit Keluarga",
                                    bootstyle="warning", padding=20)
        ortu_frame.pack(fill=X, padx=30, pady=(0, 10))

        self._ortu_inner = ortu_frame
        self._populate_ortu()

    def _populate_ortu(self):
        for w in self._ortu_inner.winfo_children():
            w.destroy()
        self.ortu_vars.clear()
        ortu_list = db.get_all_riwayat_ortu()
        cols = 2
        for idx, o in enumerate(ortu_list):
            row, col = divmod(idx, cols)
            var = tk.BooleanVar(value=False)
            nama = o["nama_penyakit"]
            self.ortu_vars[nama] = var
            cb = ttk.Checkbutton(self._ortu_inner,
                                 text=nama,
                                 variable=var,
                                 bootstyle="warning-round-toggle")
            cb.grid(row=row, column=col, sticky=W, padx=12, pady=6)
        for c in range(cols):
            self._ortu_inner.columnconfigure(c, weight=1)

        if not ortu_list:
            ttk.Label(self._ortu_inner,
                      text="Tidak ada data riwayat penyakit orang tua.",
                      font=("Segoe UI", 9), foreground="#888").pack(padx=10)

    # ─────────────────────────────────────────────────────────────────────────
    # STEP 4 – Status Imunisasi Dasar
    # ─────────────────────────────────────────────────────────────────────────
    def _build_step4(self, parent):
        ttk.Label(parent, text="Status Imunisasi Dasar",
                  font=("Segoe UI", 13, "bold")).pack(anchor=W, padx=30, pady=(20, 4))
        ttk.Label(parent,
                  text="Tandai status imunisasi dasar balita.\n"
                       "Data ini digunakan sebagai faktor pendukung analisis.",
                  font=("Segoe UI", 9), foreground="#666",
                  justify=LEFT).pack(anchor=W, padx=30, pady=(0, 16))

        imu_frame = ttk.Labelframe(parent, text="Imunisasi Dasar Lengkap",
                                   bootstyle="info", padding=20)
        imu_frame.pack(fill=X, padx=30, pady=(0, 10))

        self._imu_inner = imu_frame
        self._populate_imunisasi()

        # Catatan
        note = ttk.Labelframe(parent, text="Catatan Sistem", bootstyle="secondary", padding=12)
        note.pack(fill=X, padx=30, pady=(10, 0))
        ttk.Label(note,
                  text="Riwayat penyakit keluarga dan status imunisasi digunakan sebagai "
                       "faktor pendukung analisis, bukan sebagai penentu utama diagnosa.\n"
                       "Diagnosa utama tetap menggunakan algoritma Fuzzy Sugeno berdasarkan gejala.",
                  font=("Segoe UI", 9), foreground="#555",
                  wraplength=700, justify=LEFT).pack(anchor=W)

    def _populate_imunisasi(self):
        for w in self._imu_inner.winfo_children():
            w.destroy()
        self.imu_vars.clear()
        imu_list = db.get_all_imunisasi()

        # Header kolom
        ttk.Label(self._imu_inner, text="Jenis Imunisasi",
                  font=("Segoe UI", 9, "bold"), width=22).grid(
            row=0, column=0, sticky=W, padx=(0, 12), pady=(0, 6))
        ttk.Label(self._imu_inner, text="Status",
                  font=("Segoe UI", 9, "bold")).grid(
            row=0, column=1, sticky=W, pady=(0, 6))
        ttk.Label(self._imu_inner, text="Keterangan",
                  font=("Segoe UI", 9, "bold")).grid(
            row=0, column=2, sticky=W, padx=(16, 0), pady=(0, 6))

        ttk.Separator(self._imu_inner, orient=HORIZONTAL).grid(
            row=1, column=0, columnspan=3, sticky=EW, pady=(0, 8))

        for idx, imu in enumerate(imu_list):
            nama = imu["nama_imunisasi"]
            var = tk.StringVar(value="Sudah")
            self.imu_vars[nama] = var

            ttk.Label(self._imu_inner, text=nama,
                      font=("Segoe UI", 9), width=22).grid(
                row=idx + 2, column=0, sticky=W, padx=(0, 12), pady=5)

            rb_frame = ttk.Frame(self._imu_inner)
            rb_frame.grid(row=idx + 2, column=1, sticky=W, pady=5)
            ttk.Radiobutton(rb_frame, text="Sudah", variable=var,
                            value="Sudah", bootstyle="success").pack(side=LEFT, padx=(0, 12))
            ttk.Radiobutton(rb_frame, text="Belum", variable=var,
                            value="Belum", bootstyle="danger").pack(side=LEFT)

            ket = imu["keterangan"] if "keterangan" in imu.keys() else ""
            ttk.Label(self._imu_inner, text=ket,
                      font=("Segoe UI", 8), foreground="#888").grid(
                row=idx + 2, column=2, sticky=W, padx=(16, 0), pady=5)

        if not imu_list:
            ttk.Label(self._imu_inner,
                      text="Tidak ada data imunisasi.",
                      font=("Segoe UI", 9), foreground="#888").grid(
                row=2, column=0, sticky=W, padx=10)

        for c in range(3):
            self._imu_inner.columnconfigure(c, weight=1 if c == 2 else 0)

    # ─────────────────────────────────────────────────────────────────────────
    # Navigasi Wizard
    # ─────────────────────────────────────────────────────────────────────────
    def _goto_step(self, step: int):
        self._current_step = step
        for i, frame in enumerate(self._steps_frames):
            frame.pack_forget()
        self._steps_frames[step].pack(fill=BOTH, expand=True)

        # Update step indicator
        colors = {
            "active":   {"num": "success", "fg": "#198754"},
            "done":     {"num": "secondary", "fg": "#6c757d"},
            "inactive": {"num": "secondary", "fg": "#adb5bd"},
        }
        for i, (num_lbl, txt_lbl) in enumerate(self._step_labels):
            if i < step:
                num_lbl.configure(foreground="#198754")
                txt_lbl.configure(foreground="#198754")
            elif i == step:
                num_lbl.configure(foreground="#0d6efd",
                                  font=("Segoe UI", 13, "bold"))
                txt_lbl.configure(foreground="#0d6efd",
                                  font=("Segoe UI", 9, "bold"))
            else:
                num_lbl.configure(foreground="#adb5bd",
                                  font=("Segoe UI", 12, "bold"))
                txt_lbl.configure(foreground="#adb5bd",
                                  font=("Segoe UI", 8))

        # Tombol nav
        self.btn_prev.configure(state=NORMAL if step > 0 else DISABLED)
        is_last = (step == len(self._steps_frames) - 1)
        if is_last:
            self.btn_next.pack_forget()
            self.btn_diagnosa.pack(side=RIGHT)
        else:
            self.btn_diagnosa.pack_forget()
            self.btn_next.pack(side=RIGHT)

    def _prev_step(self):
        if self._current_step > 0:
            self._goto_step(self._current_step - 1)

    def _next_step(self):
        if not self._validate_current_step():
            return
        if self._current_step < len(self._steps_frames) - 1:
            self._goto_step(self._current_step + 1)

    def _validate_current_step(self) -> bool:
        step = self._current_step
        if step == 0:
            nama = self.var_nama.get().strip()
            umur = self.var_umur.get().strip()
            if not nama:
                Messagebox.show_warning("Nama balita wajib diisi!", parent=self)
                return False
            if not umur:
                Messagebox.show_warning("Umur balita wajib diisi!", parent=self)
                return False
            try:
                u = int(umur)
                if u < 0 or u > 60:
                    raise ValueError
            except ValueError:
                Messagebox.show_warning(
                    "Umur harus berupa angka antara 0 sampai 60 bulan!",
                    parent=self)
                return False
        elif step == 1:
            terpilih = [gid for gid, var in self.check_vars.items() if var.get()]
            if not terpilih:
                Messagebox.show_warning(
                    "Pilih minimal 1 gejala sebelum melanjutkan!",
                    parent=self)
                return False
        return True

    # ─────────────────────────────────────────────────────────────────────────
    # Diagnosa
    # ─────────────────────────────────────────────────────────────────────────
    def _diagnosa(self):
        if not self._validate_current_step():
            return

        terpilih = [gid for gid, var in self.check_vars.items() if var.get()]
        if not terpilih:
            Messagebox.show_warning(
                "Tidak ada gejala yang dipilih. Kembali ke tahap Gejala.",
                parent=self)
            return

        # Kumpulkan riwayat ortu yang dicentang
        riwayat_ortu = [nama for nama, var in self.ortu_vars.items() if var.get()]

        # Kumpulkan status imunisasi
        status_imunisasi = {nama: var.get() for nama, var in self.imu_vars.items()}

        try:
            hasil = fz.jalankan_diagnosis(terpilih)
        except Exception as e:
            Messagebox.show_error(
                title="Error Diagnosis",
                message=f"Terjadi kesalahan saat proses diagnosis:\n{e}",
                parent=self)
            return

        if not hasil:
            Messagebox.show_warning(
                title="Hasil Kosong",
                message="Tidak ada penyakit yang cocok dengan gejala yang dipilih.",
                parent=self)
            return

        self.controller.show_page("HasilDiagnosis", data={
            "hasil":            hasil,
            "gejala_ids":       terpilih,
            "nama_pasien":      self.var_nama.get().strip(),
            "umur_pasien":      self.var_umur.get().strip(),
            "jenis_kelamin":    self.var_jk.get(),
            "riwayat_ortu":     riwayat_ortu,
            "status_imunisasi": status_imunisasi,
        })

    # ─────────────────────────────────────────────────────────────────────────
    def refresh(self):
        """Dipanggil tiap kali halaman ditampilkan ulang."""
        self._populate_gejala()
        self._populate_ortu()
        self._populate_imunisasi()
        self._goto_step(0)
        # Reset form
        self.var_nama.set("")
        self.var_umur.set("")
        self.var_jk.set("Laki-laki")
