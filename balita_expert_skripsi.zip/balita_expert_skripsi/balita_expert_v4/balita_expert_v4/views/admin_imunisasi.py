"""
views/admin_imunisasi.py - Admin Panel: CRUD Data Imunisasi Dasar
"""

import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from ttkbootstrap.dialogs import Messagebox
import database as db


class AdminImunisasiPage(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self._selected_id = None
        self._build_ui()

    def _build_ui(self):
        # ── Header ───────────────────────────────────────────────────────────
        hdr = ttk.Frame(self, bootstyle="info", padding=(20, 10))
        hdr.pack(fill=X)
        ttk.Label(hdr, text="Admin – Data Imunisasi Dasar",
                  font=("Segoe UI", 14, "bold"),
                  bootstyle="inverse-info").pack(side=LEFT)

        # ── Body ─────────────────────────────────────────────────────────────
        body = ttk.Frame(self, padding=15)
        body.pack(fill=BOTH, expand=True)
        body.columnconfigure(0, weight=3)
        body.columnconfigure(1, weight=2)
        body.rowconfigure(0, weight=1)

        # ── Kiri: Tabel ───────────────────────────────────────────────────────
        left_frame = ttk.Frame(body)
        left_frame.grid(row=0, column=0, sticky=NSEW, padx=(0, 10))

        ttk.Label(left_frame, text="Daftar Imunisasi Dasar",
                  font=("Segoe UI", 11, "bold")).pack(anchor=W, pady=(0, 8))

        table_box = ttk.Frame(left_frame)
        table_box.pack(fill=BOTH, expand=True)

        cols = ("Kode", "Nama Imunisasi", "Keterangan")
        self.tree = ttk.Treeview(table_box, columns=cols,
                                 show="headings", bootstyle="info",
                                 selectmode="browse", height=18)

        for col in cols:
            self.tree.heading(col, text=col, anchor=W)

        self.tree.column("Kode",          width=90,  anchor=W, stretch=False)
        self.tree.column("Nama Imunisasi",width=180, anchor=W)
        self.tree.column("Keterangan",    width=240, anchor=W)

        vsb = ttk.Scrollbar(table_box, orient=VERTICAL,
                             command=self.tree.yview, bootstyle="round")
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side=LEFT, fill=BOTH, expand=True)
        vsb.pack(side=RIGHT, fill=Y)
        self.tree.bind("<<TreeviewSelect>>", self._on_select)

        # ── Kanan: Form ───────────────────────────────────────────────────────
        form = ttk.Frame(body, padding=15, bootstyle="light")
        form.grid(row=0, column=1, sticky=NSEW)

        ttk.Label(form, text="Form Data Imunisasi",
                  font=("Segoe UI", 11, "bold")).pack(anchor=W, pady=(0, 10))

        ttk.Label(form, text="Kode *",
                  font=("Segoe UI", 9, "bold")).pack(anchor=W, pady=(8, 2))
        self.ent_kode = ttk.Entry(form)
        self.ent_kode.pack(fill=X)

        ttk.Label(form, text="Nama Imunisasi *",
                  font=("Segoe UI", 9, "bold")).pack(anchor=W, pady=(8, 2))
        self.ent_nama = ttk.Entry(form)
        self.ent_nama.pack(fill=X)

        ttk.Label(form, text="Keterangan",
                  font=("Segoe UI", 9, "bold")).pack(anchor=W, pady=(8, 2))
        self.ent_ket = ttk.Entry(form)
        self.ent_ket.pack(fill=X)

        ttk.Label(form,
                  text='Contoh kode: IMU006. Kode harus unik.',
                  font=("Segoe UI", 8), foreground="#888").pack(anchor=W, pady=(6, 0))

        btn = ttk.Frame(form, padding=(0, 15))
        btn.pack(fill=X)

        ttk.Button(btn, text="Tambah", bootstyle="success",
                   command=self._tambah).pack(side=LEFT, padx=(0, 5))
        ttk.Button(btn, text="Ubah", bootstyle="warning",
                   command=self._ubah).pack(side=LEFT, padx=5)
        ttk.Button(btn, text="Hapus", bootstyle="danger",
                   command=self._hapus).pack(side=LEFT, padx=5)
        ttk.Button(btn, text="Reset", bootstyle="secondary",
                   command=self._reset_form).pack(side=RIGHT)
        ttk.Button(btn, text="🖨 Cetak Laporan", bootstyle="primary",
                   command=self._cetak_laporan).pack(side=RIGHT, padx=(0, 5))

        self._load_data()

    # ── Data ─────────────────────────────────────────────────────────────────
    def _load_data(self):
        self.tree.delete(*self.tree.get_children())
        for imu in db.get_all_imunisasi():
            self.tree.insert("", END, iid=str(imu["id"]),
                             values=(imu["kode"], imu["nama_imunisasi"],
                                     imu["keterangan"] if "keterangan" in imu.keys() else ""))

    def _on_select(self, _event=None):
        sel = self.tree.selection()
        if not sel:
            return
        iid = int(sel[0])
        self._selected_id = iid
        imu = db.get_imunisasi_by_id(iid)
        if not imu:
            return
        self.ent_kode.delete(0, END)
        self.ent_kode.insert(0, imu["kode"])
        self.ent_nama.delete(0, END)
        self.ent_nama.insert(0, imu["nama_imunisasi"])
        self.ent_ket.delete(0, END)
        self.ent_ket.insert(0, imu.get("keterangan") or "")

    def _get_form(self):
        return (self.ent_kode.get().strip(),
                self.ent_nama.get().strip(),
                self.ent_ket.get().strip())

    def _reset_form(self):
        self._selected_id = None
        for w in (self.ent_kode, self.ent_nama, self.ent_ket):
            w.delete(0, END)
        self.tree.selection_remove(self.tree.selection())

    def _validate(self, kode, nama):
        if not kode or not nama:
            Messagebox.show_warning("Kode dan Nama Imunisasi wajib diisi!", parent=self)
            return False
        return True

    # ── CRUD ─────────────────────────────────────────────────────────────────
    def _tambah(self):
        kode, nama, ket = self._get_form()
        if not self._validate(kode, nama):
            return
        try:
            db.insert_imunisasi(kode, nama, ket)
            Messagebox.show_info("Data berhasil ditambahkan.", parent=self)
            self._reset_form()
            self._load_data()
        except Exception as e:
            Messagebox.show_error(f"Gagal:\n{e}", parent=self)

    def _ubah(self):
        if not self._selected_id:
            Messagebox.show_warning("Pilih data yang ingin diubah!", parent=self)
            return
        kode, nama, ket = self._get_form()
        if not self._validate(kode, nama):
            return
        try:
            db.update_imunisasi(self._selected_id, kode, nama, ket)
            Messagebox.show_info("Data berhasil diperbarui.", parent=self)
            self._reset_form()
            self._load_data()
        except Exception as e:
            Messagebox.show_error(f"Gagal:\n{e}", parent=self)

    def _hapus(self):
        if not self._selected_id:
            Messagebox.show_warning("Pilih data yang ingin dihapus!", parent=self)
            return
        confirm = Messagebox.yesno("Hapus data ini?", parent=self)
        if confirm == "Yes":
            db.delete_imunisasi(self._selected_id)
            self._reset_form()
            self._load_data()

    def _cetak_laporan(self):
        from views.cetak_laporan_admin import cetak_laporan_admin_pdf
        data = db.get_all_imunisasi()
        headers = ["No", "Kode", "Nama Imunisasi", "Keterangan"]
        rows = []
        for i, r_row in enumerate(data, 1):
            r = dict(r_row)
            ket = r.get("keterangan") or "-"
            if len(ket) > 100: ket = ket[:97] + "..."
            rows.append([str(i), r["kode"], r["nama_imunisasi"], ket])
            
        cetak_laporan_admin_pdf(self.winfo_toplevel(), "LAPORAN DATA IMUNISASI DASAR", headers, rows)

    def refresh(self):
        self._load_data()
