"""
views/login.py - Halaman Login
Sistem Pakar Diagnosis Penyakit Balita - Metode Fuzzy Sugeno
"""

import tkinter as tk
import ttkbootstrap as ttk
from PIL import Image, ImageTk
from ttkbootstrap.constants import *
from ttkbootstrap.dialogs import Messagebox
import auth
import os


class LoginPage(ttk.Frame):
    """Halaman login dengan tampilan modern dan menarik."""

    def __init__(self, parent, on_success):
        """
        parent     : widget induk (root window)
        on_success : callback dipanggil ketika login berhasil
        """
        super().__init__(parent)
        self.on_success = on_success
        self._show_password = False
        self._build_ui()

    # ── Build UI ──────────────────────────────────────────────────────────────

    def _build_ui(self):
        # Dua kolom: panel kiri (branding) + panel kanan (form)
        self.columnconfigure(0, weight=1)
        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)

        self._build_left_panel()
        self._build_right_panel()

    # ── Panel Kiri: Branding / Hero ───────────────────────────────────────────

    def _build_left_panel(self):
        left = ttk.Frame(self, bootstyle="success", padding=0)
        left.grid(row=0, column=0, sticky=NSEW)

        # Gradient effect dengan nested frames
        inner = ttk.Frame(left, bootstyle="success", padding=(50, 60))
        inner.pack(fill=BOTH, expand=True)

        # Logo besar
        img = Image.open("assets/icons/logoibi.png")   # sesuaikan path
        img = img.resize((210, 160))          # ukuran logo
        logo = ImageTk.PhotoImage(img)

        # Label gambar
        ttk.Label(
            inner,
            image=logo,
             bootstyle="inverse-success",
                ).pack(pady=(20, 10))

        # Supaya gambar tidak dihapus garbage collector
        inner.logo = logo

        ttk.Label(
            inner,
            text="Aplikasi Pakar Balita\nBidan Puput",
            font=("Segoe UI", 24, "bold"),
            justify="center",
            anchor="center",
            bootstyle="inverse-success",
        ).pack()

        ttk.Label(
            inner,
            text="Sistem Pakar Diagnosis Penyakit Balita",
            font=("Segoe UI", 11),
            foreground="#ffffff",
            bootstyle="inverse-success",
        ).pack(pady=(4, 0))

        ttk.Label(
            inner,
            text="Metode Fuzzy Sugeno",
            font=("Segoe UI", 10, "italic"),
            foreground="#ffffff",
            bootstyle="inverse-success",
        ).pack()

        # Separator dekoratif
        sep_frame = ttk.Frame(inner, bootstyle="success")
        sep_frame.pack(pady=30, fill=X)
        ttk.Separator(sep_frame, bootstyle="light").pack(fill=X, padx=40)

        # Fitur unggulan
        features = [
            ("🧠", "Inferensi Fuzzy Sugeno", "Akurasi diagnosis tinggi"),
            ("🔐", "Sistem Login Aman",       "Multi-role: Admin & User"),
            ("📊", "Laporan Visual",           "Persentase keyakinan real-time"),
        ]
        for icon, title, sub in features:
            row = ttk.Frame(inner, bootstyle="success", padding=(0, 6))
            row.pack(fill=X, padx=20)

            ttk.Label(row, text=icon,
                      font=("Segoe UI Emoji", 18),
                      bootstyle="inverse-success",
                      width=3).pack(side=LEFT)

            col = ttk.Frame(row, bootstyle="success")
            col.pack(side=LEFT, padx=8)

            ttk.Label(col, text=title,
                      font=("Segoe UI", 10, "bold"),
                      bootstyle="inverse-success").pack(anchor=W)
            ttk.Label(col, text=sub,
                      font=("Segoe UI", 8),
                      foreground="#ffffff",
                      bootstyle="inverse-success").pack(anchor=W)

        # Footer kiri
        ttk.Label(
            inner,
            text="© 2026 – Sistem Pakar Balita",
            font=("Segoe UI", 8),
            foreground="#ffffff",
            bootstyle="inverse-success",
        ).pack(side=BOTTOM, pady=10)

    # ── Panel Kanan: Form Login ───────────────────────────────────────────────

    def _build_right_panel(self):
        right = ttk.Frame(self, padding=0)
        right.grid(row=0, column=1, sticky=NSEW)
        right.configure(style="TFrame")

        # Pusatkan form secara vertikal
        right.rowconfigure(0, weight=1)
        right.rowconfigure(2, weight=1)
        right.columnconfigure(0, weight=1)

        # Spacer atas
        ttk.Frame(right).grid(row=0, column=0)

        # Form card
        card = ttk.Frame(right, padding=(50, 40))
        card.grid(row=1, column=0, sticky=EW, padx=30)

        # Judul form
        ttk.Label(
            card,
            text="Selamat Datang",
            font=("Segoe UI", 22, "bold"),
        ).pack(anchor=W)

        ttk.Label(
            card,
            text="Masuk untuk menggunakan sistem",
            font=("Segoe UI", 10),
            foreground="#888",
        ).pack(anchor=W, pady=(2, 28))

        # Field Username
        ttk.Label(card, text="Username",
                  font=("Segoe UI", 10, "bold")).pack(anchor=W, pady=(0, 4))

        user_frame = ttk.Frame(card)
        user_frame.pack(fill=X, pady=(0, 4))

        ttk.Label(user_frame, text="👤",
                  font=("Segoe UI Emoji", 12)).pack(side=LEFT, padx=(0, 6))

        self.entry_username = ttk.Entry(
            user_frame,
            font=("Segoe UI", 11),
            bootstyle="success",
        )
        self.entry_username.pack(side=LEFT, fill=X, expand=True, ipady=6)

        ttk.Label(card, text="",
                  font=("Segoe UI", 2)).pack()  # spacer

        # Field Password
        ttk.Label(card, text="Password",
                  font=("Segoe UI", 10, "bold")).pack(anchor=W, pady=(8, 4))

        pass_frame = ttk.Frame(card)
        pass_frame.pack(fill=X, pady=(0, 4))

        ttk.Label(pass_frame, text="🔒",
                  font=("Segoe UI Emoji", 12)).pack(side=LEFT, padx=(0, 6))

        self.entry_password = ttk.Entry(
            pass_frame,
            font=("Segoe UI", 11),
            show="●",
            bootstyle="success",
        )
        self.entry_password.pack(side=LEFT, fill=X, expand=True, ipady=6)

        # Toggle show/hide password
        self.btn_toggle = ttk.Button(
            pass_frame,
            text="👁",
            bootstyle="secondary-outline",
            command=self._toggle_password,
            width=3,
        )
        self.btn_toggle.pack(side=LEFT, padx=(6, 0))

        # Label error (tersembunyi sampai ada error)
        self.lbl_error = ttk.Label(
            card,
            text="",
            font=("Segoe UI", 9),
            foreground="#e74c3c",
        )
        self.lbl_error.pack(anchor=W, pady=(4, 0))

        # Tombol Login
        ttk.Button(
            card,
            text="  🔑  Masuk  ",
            bootstyle="success",
            command=self._do_login,
            width=30,
        ).pack(fill=X, pady=(20, 8), ipady=8)

        # Spacer bawah
        ttk.Frame(right).grid(row=2, column=0)

        # Bind Enter key
        self.entry_username.bind("<Return>", lambda e: self.entry_password.focus())
        self.entry_password.bind("<Return>", lambda e: self._do_login())

        # Fokus otomatis ke username
        self.entry_username.focus_set()

    # ── Actions ───────────────────────────────────────────────────────────────

    def _toggle_password(self):
        self._show_password = not self._show_password
        if self._show_password:
            self.entry_password.configure(show="")
            self.btn_toggle.configure(text="🙈")
        else:
            self.entry_password.configure(show="●")
            self.btn_toggle.configure(text="👁")

    def _do_login(self):
        username = self.entry_username.get()
        password = self.entry_password.get()

        ok, msg = auth.login(username, password)

        if ok:
            self.lbl_error.configure(text="")
            self.on_success()
        else:
            self.lbl_error.configure(text=f"⚠  {msg}")
            self.entry_password.delete(0, END)
            self.entry_password.focus_set()

    def clear(self):
        """Reset form login."""
        self.entry_username.delete(0, END)
        self.entry_password.delete(0, END)
        self.lbl_error.configure(text="")
        self.entry_username.focus_set()
