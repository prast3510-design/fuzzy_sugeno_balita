"""
views/riwayat_diagnosis.py - Halaman Riwayat Diagnosis
"""

import tkinter as tk
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from ttkbootstrap.dialogs import Messagebox
import database as db
from views.cetak_laporan import cetak_laporan


def _row(obj):
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return obj
    return dict(obj)


class RiwayatDiagnosisPage(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self._build_shell()

    def _build_shell(self):
        header = ttk.Frame(self, bootstyle="success")
        header.pack(fill=X)
        inner_h = ttk.Frame(header, bootstyle="success")
        inner_h.pack(fill=X, padx=20, pady=12)

        ttk.Label(inner_h, text="Riwayat Diagnosis",
                  font=("Segoe UI", 16, "bold"),
                  bootstyle="inverse-success").pack(side=LEFT)

        ttk.Button(inner_h, text="  Hapus Semua",
                   bootstyle="danger-outline",
                   command=self._hapus_semua).pack(side=RIGHT)

        ttk.Button(inner_h, text="  Refresh",
                   bootstyle="light",
                   command=self.refresh).pack(side=RIGHT, padx=(0, 8))

        filter_frame = ttk.Frame(self)
        filter_frame.pack(fill=X, padx=20, pady=(10, 0))

        ttk.Label(filter_frame, text="Cari nama pasien:",
                  font=("Segoe UI", 9)).pack(side=LEFT)
        self.var_search = tk.StringVar()
        self.var_search.trace_add("write", lambda *_: self._render_tabel())
        ttk.Entry(filter_frame, textvariable=self.var_search,
                  width=30).pack(side=LEFT, padx=(6, 0))

        ttk.Button(filter_frame, text="Reset",
                   bootstyle="secondary-outline",
                   command=lambda: self.var_search.set("")
                   ).pack(side=LEFT, padx=(6, 0))

        ttk.Separator(self, orient=HORIZONTAL).pack(fill=X, pady=(10, 0))

        self.content_frame = ttk.Frame(self)
        self.content_frame.pack(fill=BOTH, expand=True)

    def _render_tabel(self):
        for w in self.content_frame.winfo_children():
            w.destroy()

        keyword = self.var_search.get().strip().lower()
        semua = db.get_all_riwayat()

        if keyword:
            semua = [r for r in semua
                     if keyword in (r["nama_pasien"] or "").lower()]

        if not semua:
            ttk.Label(
                self.content_frame,
                text="Belum ada riwayat diagnosis." if not keyword
                     else "Tidak ada riwayat yang cocok dengan pencarian.",
                font=("Segoe UI", 12),
                foreground="#888",
            ).pack(expand=True, pady=60)
            return

        cols = ("no", "tanggal", "nama_pasien", "umur", "jk", "penyakit_utama", "skor", "kepastian")

        wrap = ttk.Frame(self.content_frame)
        wrap.pack(fill=BOTH, expand=True, padx=16, pady=12)

        tree = ttk.Treeview(
            wrap,
            columns=cols,
            show="headings",
            bootstyle="info",
            selectmode="browse",
        )

        tree.heading("no",             text="No",          anchor=CENTER)
        tree.heading("tanggal",        text="Tanggal",     anchor=W)
        tree.heading("nama_pasien",    text="Nama Pasien", anchor=W)
        tree.heading("umur",           text="Umur",        anchor=CENTER)
        tree.heading("jk",             text="JK",          anchor=CENTER)
        tree.heading("penyakit_utama", text="Penyakit Utama", anchor=W)
        tree.heading("skor",           text="Skor (%)",    anchor=CENTER)
        tree.heading("kepastian",      text="Kepastian",   anchor=CENTER)

        tree.column("no",             width=36,  anchor=CENTER, stretch=False)
        tree.column("tanggal",        width=155, anchor=W)
        tree.column("nama_pasien",    width=130, anchor=W)
        tree.column("umur",           width=60,  anchor=CENTER, stretch=False)
        tree.column("jk",             width=70,  anchor=CENTER, stretch=False)
        tree.column("penyakit_utama", width=200, anchor=W)
        tree.column("skor",           width=75,  anchor=CENTER, stretch=False)
        tree.column("kepastian",      width=110, anchor=CENTER, stretch=False)

        tree.tag_configure("Sangat Tinggi", foreground="#c0392b")
        tree.tag_configure("Tinggi",        foreground="#d35400")
        tree.tag_configure("Sedang",        foreground="#b7950b")
        tree.tag_configure("Rendah",        foreground="#1e8449")
        tree.tag_configure("Sangat Rendah", foreground="#717d7e")
        tree.tag_configure("odd",  background="#f8f9fa")
        tree.tag_configure("even", background="#ffffff")

        self._id_map = {}
        import fuzzy as fz
        import json

        for idx, r in enumerate(semua, 1):
            r = _row(r)
            try:
                hasil_json = json.loads(r.get("hasil_json") or "[]")
                top = hasil_json[0] if hasil_json else {}
                penyakit_utama = top.get("nama_penyakit", "-")
                skor = f"{top.get('persentase', 0):.1f}%"
                kepastian = fz.label_kepastian(top.get("persentase", 0))
            except Exception:
                penyakit_utama = "-"
                skor = "-"
                kepastian = "-"

            jk = r.get("jenis_kelamin") or "-"
            bg_tag = "odd" if idx % 2 == 1 else "even"
            iid = str(r["id"])
            tree.insert("", END, iid=iid, tags=(bg_tag, kepastian), values=(
                idx,
                r.get("tanggal", "-"),
                r.get("nama_pasien") or "(tidak diisi)",
                r.get("umur_pasien") or "-",
                jk,
                penyakit_utama,
                skor,
                kepastian,
            ))
            self._id_map[iid] = r["id"]

        sb_y = ttk.Scrollbar(wrap, orient=VERTICAL,
                              command=tree.yview, bootstyle="round")
        tree.configure(yscrollcommand=sb_y.set)
        sb_y.pack(side=RIGHT, fill=Y)
        tree.pack(side=LEFT, fill=BOTH, expand=True)

        action_frame = ttk.Frame(self.content_frame)
        action_frame.pack(fill=X, padx=16, pady=(0, 12))

        ttk.Label(action_frame,
                  text=f"Total: {len(semua)} riwayat  |  Klik baris untuk detail",
                  font=("Segoe UI", 8),
                  foreground="#888").pack(side=LEFT)

        ttk.Button(action_frame, text="  Lihat Detail",
                   bootstyle="info",
                   command=lambda: self._lihat_detail(tree)).pack(side=RIGHT)

        ttk.Button(action_frame, text="  Cetak Laporan",
                   bootstyle="warning",
                   command=lambda: self._cetak_dari_riwayat(tree)).pack(side=RIGHT, padx=(0, 8))

        ttk.Button(action_frame, text="  Hapus",
                   bootstyle="danger-outline",
                   command=lambda: self._hapus_satu(tree)).pack(side=RIGHT, padx=(0, 8))

        tree.bind("<Double-1>", lambda e: self._lihat_detail(tree))

    def _lihat_detail(self, tree):
        sel = tree.selection()
        if not sel:
            Messagebox.show_warning("Pilih salah satu baris terlebih dahulu.",
                                    title="Belum Dipilih", parent=self)
            return
        rid = self._id_map.get(sel[0])
        if rid is None:
            return
        riwayat = _row(db.get_riwayat_by_id(rid))
        if not riwayat:
            return
        _DetailDialog(self.winfo_toplevel(), riwayat)

    def _cetak_dari_riwayat(self, tree):
        import json, types
        sel = tree.selection()
        if not sel:
            Messagebox.show_warning("Pilih salah satu baris terlebih dahulu.",
                                    title="Belum Dipilih", parent=self)
            return
        rid = self._id_map.get(sel[0])
        if rid is None:
            return
        riwayat = _row(db.get_riwayat_by_id(rid))
        if not riwayat:
            return

        try:
            hasil_json = json.loads(riwayat.get("hasil_json") or "[]")
            gejala_ids = json.loads(riwayat.get("gejala_ids_json") or "[]")
            riwayat_ortu = json.loads(riwayat.get("riwayat_ortu_json") or "[]")
            status_imunisasi = json.loads(riwayat.get("status_imunisasi_json") or "{}")
        except Exception:
            hasil_json = []
            gejala_ids = []
            riwayat_ortu = []
            status_imunisasi = {}

        hasil_objs = []
        for h in hasil_json:
            obj = types.SimpleNamespace(
                penyakit_id   = h.get("penyakit_id", 0),
                nama_penyakit = h.get("nama_penyakit", "-"),
                persentase    = h.get("persentase", 0.0),
            )
            hasil_objs.append(obj)

        data = {
            "hasil": hasil_objs,
            "gejala_ids": gejala_ids,
            "riwayat_ortu": riwayat_ortu,
            "status_imunisasi": status_imunisasi,
        }
        cetak_laporan(
            parent_window=self.winfo_toplevel(),
            data=data,
            nama_pasien=riwayat.get("nama_pasien") or "",
            umur=riwayat.get("umur_pasien") or "",
        )

    def _hapus_satu(self, tree):
        sel = tree.selection()
        if not sel:
            Messagebox.show_warning("Pilih salah satu baris terlebih dahulu.",
                                    title="Belum Dipilih", parent=self)
            return
        rid = self._id_map.get(sel[0])
        if rid is None:
            return
        confirm = Messagebox.yesno(
            title="Konfirmasi Hapus",
            message="Hapus riwayat diagnosis ini?",
            parent=self)
        if confirm == "Yes":
            db.delete_riwayat(rid)
            self._render_tabel()

    def _hapus_semua(self):
        if not db.get_all_riwayat():
            Messagebox.show_info("Tidak ada riwayat untuk dihapus.",
                                 title="Info", parent=self)
            return
        confirm = Messagebox.yesno(
            title="Konfirmasi Hapus Semua",
            message="Hapus SEMUA riwayat diagnosis? Tindakan ini tidak dapat dibatalkan.",
            parent=self, alert=True)
        if confirm == "Yes":
            db.delete_all_riwayat()
            self._render_tabel()

    def refresh(self):
        self._render_tabel()


# ── Dialog Detail Riwayat ─────────────────────────────────────────────────────
class _DetailDialog(tk.Toplevel):
    def __init__(self, parent, riwayat: dict):
        super().__init__(parent)
        self.title("Detail Riwayat Diagnosis")
        self.geometry("660x600")
        self.resizable(True, True)
        self.transient(parent)
        self.lift()
        self._build(riwayat)
        self.update_idletasks()
        self.grab_set()
        self.focus_force()

    def _build(self, r: dict):
        import json
        import fuzzy as fz

        # Header
        hdr = ttk.Frame(self, bootstyle="info")
        hdr.pack(fill=X)
        ttk.Label(hdr, text="  Detail Riwayat Diagnosis",
                  font=("Segoe UI", 12, "bold"),
                  bootstyle="inverse-info").pack(side=LEFT, padx=10, pady=10)
        ttk.Button(hdr, text="Tutup", bootstyle="light",
                   command=self.destroy).pack(side=RIGHT, padx=10, pady=6)

        # Scroll area
        canvas = tk.Canvas(self, highlightthickness=0)
        sb = ttk.Scrollbar(self, orient=VERTICAL,
                            command=canvas.yview, bootstyle="round")
        inner = ttk.Frame(canvas)
        inner.bind("<Configure>",
                   lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=inner, anchor=NW)
        canvas.configure(yscrollcommand=sb.set)
        canvas.pack(side=LEFT, fill=BOTH, expand=True)
        sb.pack(side=RIGHT, fill=Y)
        canvas.bind_all("<MouseWheel>",
                        lambda e: canvas.yview_scroll(-1 * (e.delta // 120), "units"))

        pad = {"padx": 20, "pady": 3}

        # ── Identitas ─────────────────────────────────────────────────────────
        ttk.Label(inner, text="Identitas Pasien",
                  font=("Segoe UI", 10, "bold")).pack(anchor=W, padx=20, pady=(14, 4))
        ttk.Separator(inner, orient=HORIZONTAL).pack(fill=X, padx=20)

        jk = r.get("jenis_kelamin") or "-"
        info = [
            ("Tanggal",       r.get("tanggal", "-")),
            ("Nama Pasien",   r.get("nama_pasien") or "(tidak diisi)"),
            ("Umur Pasien",   f"{r.get('umur_pasien') or '-'} bulan"),
            ("Jenis Kelamin", jk),
        ]
        for lbl, val in info:
            row = ttk.Frame(inner)
            row.pack(fill=X, **pad)
            ttk.Label(row, text=lbl + ":", width=18,
                      font=("Segoe UI", 9, "bold")).pack(side=LEFT)
            ttk.Label(row, text=val,
                      font=("Segoe UI", 9)).pack(side=LEFT)

        # ── Gejala ────────────────────────────────────────────────────────────
        ttk.Label(inner, text="Gejala yang Dilaporkan",
                  font=("Segoe UI", 10, "bold")).pack(anchor=W, padx=20, pady=(14, 4))
        ttk.Separator(inner, orient=HORIZONTAL).pack(fill=X, padx=20)

        try:
            gejala_ids = json.loads(r.get("gejala_ids_json") or "[]")
            all_gejala = {g["id"]: _row(g) for g in db.get_all_gejala()}
            gejala_list = [all_gejala[gid] for gid in gejala_ids if gid in all_gejala]
        except Exception:
            gejala_list = []

        if gejala_list:
            g_frame = ttk.Frame(inner)
            g_frame.pack(fill=X, padx=20, pady=4)
            cols = 2
            for idx, g in enumerate(gejala_list):
                rr, cc = divmod(idx, cols)
                ttk.Label(g_frame, text=f"[{g['kode']}] {g['nama']}",
                          font=("Segoe UI", 9)).grid(row=rr, column=cc, sticky=W, padx=6, pady=2)
        else:
            ttk.Label(inner, text="(tidak ada data)",
                      font=("Segoe UI", 9), foreground="#888").pack(anchor=W, padx=26)

        # ── Riwayat Orang Tua ─────────────────────────────────────────────────
        ttk.Label(inner, text="Riwayat Penyakit Orang Tua",
                  font=("Segoe UI", 10, "bold")).pack(anchor=W, padx=20, pady=(14, 4))
        ttk.Separator(inner, orient=HORIZONTAL).pack(fill=X, padx=20)

        try:
            ortu_list = json.loads(r.get("riwayat_ortu_json") or "[]")
        except Exception:
            ortu_list = []

        if ortu_list:
            for o in ortu_list:
                ttk.Label(inner, text=f"  ⚕  {o}",
                          font=("Segoe UI", 9),
                          foreground="#0d6efd").pack(anchor=W, padx=20, pady=2)
        else:
            ttk.Label(inner, text="  (tidak ada / tidak diisi)",
                      font=("Segoe UI", 9), foreground="#888").pack(anchor=W, padx=20, pady=2)

        # ── Status Imunisasi ──────────────────────────────────────────────────
        ttk.Label(inner, text="Status Imunisasi Dasar",
                  font=("Segoe UI", 10, "bold")).pack(anchor=W, padx=20, pady=(14, 4))
        ttk.Separator(inner, orient=HORIZONTAL).pack(fill=X, padx=20)

        try:
            imu_dict = json.loads(r.get("status_imunisasi_json") or "{}")
        except Exception:
            imu_dict = {}

        if imu_dict:
            imu_frame = ttk.Frame(inner)
            imu_frame.pack(fill=X, padx=24, pady=4)
            for i, (nama, status) in enumerate(imu_dict.items()):
                color = "#198754" if status == "Sudah" else "#dc3545"
                icon = "✓" if status == "Sudah" else "✗"
                row = ttk.Frame(imu_frame)
                row.pack(fill=X, pady=2)
                ttk.Label(row, text=f"{icon}  {nama}",
                          font=("Segoe UI", 9),
                          foreground=color,
                          width=20).pack(side=LEFT)
                ttk.Label(row, text=status,
                          font=("Segoe UI", 9, "bold"),
                          foreground=color).pack(side=LEFT)
        else:
            ttk.Label(inner, text="  (tidak ada data imunisasi)",
                      font=("Segoe UI", 9), foreground="#888").pack(anchor=W, padx=20, pady=2)

        # ── Hasil Diagnosis ───────────────────────────────────────────────────
        ttk.Label(inner, text="Hasil Diagnosis",
                  font=("Segoe UI", 10, "bold")).pack(anchor=W, padx=20, pady=(14, 4))
        ttk.Separator(inner, orient=HORIZONTAL).pack(fill=X, padx=20)

        try:
            hasil_json = json.loads(r.get("hasil_json") or "[]")
        except Exception:
            hasil_json = []

        WARNA = {
            "Sangat Tinggi": "#c0392b",
            "Tinggi":        "#d35400",
            "Sedang":        "#b7950b",
            "Rendah":        "#1e8449",
            "Sangat Rendah": "#717d7e",
        }

        for rank, h in enumerate(hasil_json[:5], 1):
            label = fz.label_kepastian(h.get("persentase", 0))
            color = WARNA.get(label, "#555")
            row = ttk.Frame(inner)
            row.pack(fill=X, padx=20, pady=2)
            ttk.Label(row,
                      text=f"{rank}. {h.get('nama_penyakit', '-')}",
                      font=("Segoe UI", 9, "bold")).pack(side=LEFT)
            ttk.Label(row,
                      text=f"  {h.get('persentase', 0):.1f}%  |  {label}",
                      font=("Segoe UI", 9),
                      foreground=color).pack(side=LEFT)

        ttk.Label(inner, text="").pack(pady=8)
