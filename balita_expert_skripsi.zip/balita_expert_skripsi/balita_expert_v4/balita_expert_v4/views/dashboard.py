"""
views/dashboard.py - Halaman Dashboard
Menampilkan statistik sistem + statistik diagnosa baru
"""

import ttkbootstrap as ttk
from ttkbootstrap.constants import *
import database as db
import matplotlib
matplotlib.use("Agg")
import matplotlib.patches as mpatches
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from collections import Counter


class DashboardPage(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self._build_ui()

    def _build_ui(self):
        outer = ttk.Frame(self)
        outer.pack(fill=BOTH, expand=True)

        canvas_scroll = ttk.Canvas(outer, highlightthickness=0)
        scrollbar = ttk.Scrollbar(outer, orient=VERTICAL, command=canvas_scroll.yview)
        canvas_scroll.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side=RIGHT, fill=Y)
        canvas_scroll.pack(side=LEFT, fill=BOTH, expand=True)

        self._inner = ttk.Frame(canvas_scroll)
        self._inner_id = canvas_scroll.create_window((0, 0), window=self._inner, anchor="nw")

        def _on_configure(event):
            canvas_scroll.configure(scrollregion=canvas_scroll.bbox("all"))

        def _on_canvas_resize(event):
            canvas_scroll.itemconfig(self._inner_id, width=event.width)

        self._inner.bind("<Configure>", _on_configure)
        canvas_scroll.bind("<Configure>", _on_canvas_resize)
        canvas_scroll.bind_all(
            "<MouseWheel>",
            lambda e: canvas_scroll.yview_scroll(int(-1 * (e.delta / 120)), "units"),
        )

        # ── Header ────────────────────────────────────────────────────────────
        header = ttk.Frame(self._inner, bootstyle="success")
        header.pack(fill=X)
        inner_h = ttk.Frame(header, bootstyle="success")
        inner_h.pack(fill=X, padx=24, pady=16)

        left_header = ttk.Frame(inner_h, bootstyle="success")
        left_header.pack(side=LEFT)

        ttk.Label(left_header,
                  text="Sistem Pakar Diagnosis Penyakit Balita",
                  font=("Segoe UI", 18, "bold"),
                  bootstyle="inverse-success").pack(anchor=W)
        ttk.Label(left_header,
                  text="Sistem Pakar Berbasis Metode Fuzzy Sugeno",
                  font=("Segoe UI", 10),
                  bootstyle="inverse-success").pack(anchor=W, pady=(2, 0))

        ttk.Button(inner_h, text="  Mulai Diagnosis  ",
                   bootstyle="primary-outline",
                   command=lambda: self.controller.show_page("InputGejala"),
                   ).pack(side=RIGHT, padx=(0, 4))

        # ── Stat Cards Baris 1: Knowledge Base ───────────────────────────────
        ttk.Label(self._inner, text="Basis Pengetahuan",
                  font=("Segoe UI", 10, "bold"),
                  foreground="#555").pack(anchor=W, padx=20, pady=(16, 2))

        stat_outer1 = ttk.Frame(self._inner)
        stat_outer1.pack(fill=X, padx=20)

        penyakit_count = len(db.get_all_penyakit())
        gejala_count   = len(db.get_all_gejala())
        try:
            rule_count = len(db.get_all_rules())
        except Exception:
            rule_count = 0

        cards1 = [
            ("📦", "Data Penyakit",  str(penyakit_count), "danger"),
            ("📋", "Data Gejala",    str(gejala_count),   "warning"),
            ("⚙️", "Aturan (Rule)",  str(rule_count),     "info"),
        ]
        for col, (icon, label, value, style) in enumerate(cards1):
            self._stat_card(stat_outer1, icon, label, value, style, col)
            stat_outer1.columnconfigure(col, weight=1)

        # ── Stat Cards Baris 2: Diagnosa ─────────────────────────────────────
        ttk.Label(self._inner, text="Statistik Diagnosa",
                  font=("Segoe UI", 11, "bold"),
                  foreground="#555").pack(anchor=W, padx=20, pady=(20, 4))

        stat_outer2 = ttk.Frame(self._inner)
        stat_outer2.pack(fill=X, padx=20)

        try:
            stats = db.get_stats_dashboard()
        except Exception:
            stats = {
                "total_diagnosa": 0,
                "penyakit_terbanyak": "-",
                "penyakit_terbanyak_count": 0,
                "ortu_terbanyak": "-",
                "ortu_terbanyak_count": 0,
                "belum_lengkap_imunisasi": 0,
            }

        cards2 = [
            ("🩺", "Total Diagnosa",
             str(stats["total_diagnosa"]), "primary"),
            ("📈", f"Penyakit Terbanyak\n({stats['penyakit_terbanyak']})",
             str(stats["penyakit_terbanyak_count"]), "danger"),
            ("👨‍👩‍👧", f"Riwayat Ortu Terbanyak\n({stats['ortu_terbanyak']})",
             str(stats["ortu_terbanyak_count"]), "warning"),
            ("💉", "Belum Imunisasi\nLengkap",
             str(stats["belum_lengkap_imunisasi"]), "secondary"),
        ]
        for col, (icon, label, value, style) in enumerate(cards2):
            self._stat_card_wrap(stat_outer2, icon, label, value, style, col)
            stat_outer2.columnconfigure(col, weight=1)

        # ── Chart Row ─────────────────────────────────────────────────────────
        chart_section = ttk.Frame(self._inner)
        chart_section.pack(fill=X, padx=20, pady=(18, 0))
        chart_section.columnconfigure(0, weight=3)
        chart_section.columnconfigure(1, weight=2)

        left_outer = ttk.Frame(chart_section)
        left_outer.grid(row=0, column=0, padx=(0, 8), sticky=NSEW)

        lbl_left = ttk.Frame(left_outer, bootstyle="primary")
        lbl_left.pack(fill=X)
        ttk.Label(lbl_left, text="  Distribusi Gejala per Penyakit",
                  font=("Segoe UI", 10, "bold"),
                  bootstyle="inverse-primary").pack(anchor=W, padx=8, pady=6)

        left_body = ttk.Frame(left_outer)
        left_body.pack(fill=BOTH, expand=True)
        self._chart_gejala_per_penyakit(left_body)

        right_outer = ttk.Frame(chart_section)
        right_outer.grid(row=0, column=1, padx=(8, 0), sticky=NSEW)

        lbl_right = ttk.Frame(right_outer, bootstyle="info")
        lbl_right.pack(fill=X)
        ttk.Label(lbl_right, text="  Rule per Penyakit",
                  font=("Segoe UI", 10, "bold"),
                  bootstyle="inverse-info").pack(anchor=W, padx=8, pady=6)

        right_body = ttk.Frame(right_outer)
        right_body.pack(fill=BOTH, expand=True)
        self._chart_rule_per_penyakit(right_body)

        # ── Cara Penggunaan ───────────────────────────────────────────────────
        guide_section = ttk.Frame(self._inner)
        guide_section.pack(fill=BOTH, expand=True, padx=20, pady=(18, 0))

        ttk.Label(guide_section, text="Cara Penggunaan",
                  font=("Segoe UI", 12, "bold"),
                  bootstyle="primary").pack(anchor=W, pady=(0, 10))

        guide_frame = ttk.Frame(guide_section)
        guide_frame.pack(fill=BOTH, expand=True)
        guide_frame.columnconfigure(0, weight=1)
        guide_frame.columnconfigure(1, weight=1)

        steps = [
            ("[1]  Penerimaan Pasien",
             "Bidan menerima pasien dan memasukkan nama, umur, serta jenis kelamin balita pada menu Diagnosis Pasien.",
             "primary"),
            ("[2]  Wawancara Gejala",
             "Bidan mewawancarai orang tua pasien dan mencentang gejala-gejala yang dialami oleh balita.",
             "info"),
            ("[3]  Faktor Pendukung",
             "Bidan mengecek status imunisasi dasar pasien dan menanyakan riwayat penyakit orang tua.",
             "warning"),
            ("[4]  Diagnosis & Cetak",
             "Sistem Fuzzy Sugeno mengeluarkan hasil diagnosis. Bidan mencetak laporannya untuk orang tua.",
             "success"),
        ]

        for i, (title, desc, style) in enumerate(steps):
            row_i = i // 2
            col_i = i % 2
            guide_frame.rowconfigure(row_i, weight=1)
            card = ttk.Frame(guide_frame, bootstyle=style)
            card.grid(row=row_i, column=col_i, padx=6, pady=6, sticky=NSEW)
            ttk.Label(card, text=title,
                      font=("Segoe UI", 11, "bold"),
                      bootstyle=f"inverse-{style}").pack(anchor=W, padx=14, pady=(12, 0))
            ttk.Separator(card).pack(fill=X, padx=14, pady=6)
            ttk.Label(card, text=desc,
                      font=("Segoe UI", 9),
                      wraplength=340, justify=LEFT,
                      bootstyle=f"inverse-{style}").pack(anchor=W, padx=14, pady=(0, 12))

        btn_frame = ttk.Frame(self._inner)
        btn_frame.pack(fill=X, padx=20, pady=(14, 20))
        ttk.Button(btn_frame, text="  Mulai Diagnosis  ",
                   bootstyle="primary", width=25,
                   command=lambda: self.controller.show_page("InputGejala"),
                   ).pack(side=RIGHT)

    # ── Stat Cards ────────────────────────────────────────────────────────────
    def _stat_card(self, parent, icon, label, value, style, col):
        card = ttk.Frame(parent, bootstyle=style)
        card.grid(row=0, column=col, padx=6, pady=4, sticky=NSEW)
        ttk.Label(card, text=icon,
                  font=("Segoe UI", 20, "bold"),
                  bootstyle=f"inverse-{style}").pack(pady=(14, 0))
        ttk.Label(card, text=value,
                  font=("Segoe UI", 32, "bold"),
                  bootstyle=f"inverse-{style}").pack(pady=(2, 0))
        ttk.Label(card, text=label,
                  font=("Segoe UI", 10),
                  bootstyle=f"inverse-{style}").pack(pady=(0, 14))

    def _stat_card_wrap(self, parent, icon, label, value, style, col):
        """Stat card dengan label wrappable (untuk statistik diagnosa)."""
        card = ttk.Frame(parent, bootstyle=style)
        card.grid(row=0, column=col, padx=6, pady=4, sticky=NSEW)
        ttk.Label(card, text=icon,
                  font=("Segoe UI", 16, "bold"),
                  bootstyle=f"inverse-{style}").pack(pady=(10, 0))
        ttk.Label(card, text=value,
                  font=("Segoe UI", 28, "bold"),
                  bootstyle=f"inverse-{style}").pack(pady=(2, 0))
        ttk.Label(card, text=label,
                  font=("Segoe UI", 8),
                  wraplength=140, justify=CENTER,
                  bootstyle=f"inverse-{style}").pack(pady=(0, 10))

    # ── Charts ────────────────────────────────────────────────────────────────
    def _get_rule_counts(self):
        rules = db.get_all_rules()
        names = []
        for r in rules:
            try:
                names.append(r["nama_penyakit"])
            except Exception:
                try:
                    names.append(r.nama_penyakit)
                except Exception:
                    pass
        return Counter(names)

    def _chart_gejala_per_penyakit(self, parent):
        try:
            counts = self._get_rule_counts()
            if not counts:
                raise ValueError("empty")
            labels = list(counts.keys())
            values = list(counts.values())
            short_labels = [l if len(l) <= 16 else l[:14] + "..." for l in labels]
        except Exception:
            labels = ["Tidak ada data"]
            values = [0]
            short_labels = ["Tidak ada data"]

        bar_palette = [
            "#E25C5C", "#E2975C", "#E2CC5C", "#5CB9E2",
            "#5C7FE2", "#A05CE2", "#5CE2A0", "#E25CAD",
        ]
        bar_colors = [bar_palette[i % len(bar_palette)] for i in range(len(labels))]
        fig_h = max(2.8, len(labels) * 0.45 + 0.6)
        fig = Figure(figsize=(5.8, fig_h), dpi=90)
        fig.patch.set_facecolor("#f8f9fa")
        ax = fig.add_subplot(111)
        ax.set_facecolor("#f8f9fa")

        bars = ax.barh(short_labels[::-1], values[::-1],
                       color=bar_colors[::-1], height=0.6,
                       edgecolor="white", linewidth=0.5)

        max_val = max(values) if values else 1
        for bar, val in zip(bars, values[::-1]):
            ax.text(bar.get_width() + max_val * 0.02,
                    bar.get_y() + bar.get_height() / 2,
                    str(val), va="center", ha="left", fontsize=8, color="#444")

        ax.set_xlabel("Jumlah Rule", fontsize=8, color="#666")
        ax.tick_params(axis="both", labelsize=8, colors="#555")
        ax.set_xlim(0, max_val * 1.18)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.spines["left"].set_color("#ccc")
        ax.spines["bottom"].set_color("#ccc")
        ax.xaxis.grid(True, color="#e0e0e0", linestyle="--", linewidth=0.6)
        ax.set_axisbelow(True)
        fig.tight_layout(pad=1.2)

        canvas = FigureCanvasTkAgg(fig, master=parent)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=BOTH, expand=True)

    def _chart_rule_per_penyakit(self, parent):
        try:
            counts = self._get_rule_counts()
            if not counts:
                raise ValueError("empty")
            labels = list(counts.keys())
            values = list(counts.values())
        except Exception:
            labels = ["Tidak ada data"]
            values = [1]

        pie_palette = [
            "#5CB9E2", "#E25C5C", "#5CE2A0", "#E2CC5C",
            "#A05CE2", "#E2975C", "#E25CAD", "#5C7FE2",
        ]
        pie_colors = [pie_palette[i % len(pie_palette)] for i in range(len(labels))]

        fig = Figure(figsize=(3.6, 3.4), dpi=90)
        fig.patch.set_facecolor("#f8f9fa")
        ax = fig.add_subplot(111)
        ax.set_facecolor("#f8f9fa")

        wedges, texts, autotexts = ax.pie(
            values, labels=None, colors=pie_colors,
            autopct="%1.0f%%", pctdistance=0.75, startangle=90,
            wedgeprops={"width": 0.55, "edgecolor": "white", "linewidth": 2},
        )
        for at in autotexts:
            at.set_fontsize(7)
            at.set_color("white")
            at.set_fontweight("bold")

        display_labels = [(l[:11] + "...") if len(l) > 14 else l for l in labels]
        legend_patches = [
            mpatches.Patch(color=pie_colors[i],
                           label=f"{display_labels[i]} ({values[i]})")
            for i in range(min(len(labels), 8))
        ]
        ax.legend(handles=legend_patches, loc="lower center",
                  bbox_to_anchor=(0.5, -0.28), ncol=2, fontsize=7,
                  frameon=False, handlelength=1.0, handletextpad=0.4,
                  labelcolor="#444")
        fig.tight_layout(pad=0.5)

        canvas = FigureCanvasTkAgg(fig, master=parent)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=BOTH, expand=True)

    def refresh(self):
        for widget in self.winfo_children():
            widget.destroy()
        self._build_ui()
