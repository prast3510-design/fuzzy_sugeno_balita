"""
views/cetak_laporan_admin.py - Modul Cetak Laporan PDF untuk Halaman Admin
"""

import os
import datetime
import locale
import tkinter as tk
import tkinter.filedialog as fd
from ttkbootstrap.dialogs import Messagebox
import auth


def cetak_laporan_admin_pdf(parent_window, title_laporan, headers, data_rows):
    """
    Fungsi untuk mencetak laporan admin (tabel) ke dalam format PDF.
    - title_laporan: string (misal: "LAPORAN DATA PENYAKIT")
    - headers: list of string untuk header tabel
    - data_rows: list of list untuk isi tabel
    """
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib import colors
        from reportlab.lib.units import cm
        from reportlab.platypus import (SimpleDocTemplate, Paragraph,
                                         Spacer, Table, TableStyle, HRFlowable)
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY
        from reportlab.platypus import Image
    except ImportError:
        Messagebox.show_error(
            "Library 'reportlab' tidak ditemukan.\nSilakan jalankan: pip install reportlab",
            title="Error", parent=parent_window
        )
        return

    path = fd.asksaveasfilename(
        parent=parent_window,
        defaultextension=".pdf",
        filetypes=[("PDF Files", "*.pdf"), ("All Files", "*.*")],
        initialfile=f"Laporan_{title_laporan.replace(' ', '_')}_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf",
        title="Simpan Laporan PDF"
    )
    if not path:
        return

    try:
        doc = SimpleDocTemplate(path, pagesize=A4,
                                 leftMargin=2*cm, rightMargin=2*cm,
                                 topMargin=2*cm, bottomMargin=2*cm)

        HEADER_COLOR = colors.HexColor("#1a5276")
        LIGHT_COLOR  = colors.HexColor("#d6eaf8")
        GRAY_COLOR   = colors.HexColor("#888888")

        judul_style = ParagraphStyle("Judul", fontSize=15,
            fontName="Times-Bold", alignment=TA_CENTER,
            spaceAfter=4, textColor=HEADER_COLOR)
        sub_style = ParagraphStyle("Sub", fontSize=10,
            fontName="Times-Roman", alignment=TA_CENTER,
            spaceAfter=2, textColor=colors.HexColor("#555555"))
        footer_style = ParagraphStyle("Footer", fontSize=7,
            fontName="Times-Italic", textColor=GRAY_COLOR,
            alignment=TA_CENTER)

        story = []

        # ================= KOP SURAT =================
        logo_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'assets', 'icons', 'logoibi.png')
        
        if os.path.exists(logo_path):
            logo = Image(logo_path, width=2.5*cm, height=2.5*cm)
            t_logo = Table([[logo]], colWidths=[16*cm])
            t_logo.setStyle(TableStyle([
                ('ALIGN', (0,0), (-1,-1), 'CENTER'),
                ('BOTTOMPADDING', (0,0), (-1,-1), 8)
            ]))
            story.append(t_logo)
            
            story.append(Paragraph("KLINIK BIDAN", ParagraphStyle(
                "KopJudul", fontSize=14, fontName="Times-Bold", alignment=TA_CENTER, spaceAfter=4, textColor=HEADER_COLOR
            )))
            story.append(Paragraph("Sistem Pakar Diagnosis Penyakit Balita Metode Fuzzy Sugeno", ParagraphStyle(
                "KopSub", fontSize=10, fontName="Times-Roman", alignment=TA_CENTER, spaceAfter=2
            )))
            story.append(Paragraph("Jl. Almubarok II No.32 RT005/RW010, Cipulir, Kebayoran Lama, Jakarta Selatan.", ParagraphStyle(
                "KopAlamat", fontSize=9, fontName="Times-Roman", alignment=TA_CENTER
            )))
            story.append(Spacer(1, 10))
            story.append(HRFlowable(width="100%", thickness=2, color=colors.black, spaceAfter=2))
            story.append(HRFlowable(width="100%", thickness=1, color=colors.black, spaceAfter=15))
            
            story.append(Paragraph(title_laporan, judul_style))
            story.append(Spacer(1, 10))
        else:
            story.append(Paragraph("SISTEM PAKAR DIAGNOSIS PENYAKIT BALITA", judul_style))
            story.append(Paragraph("Metode Fuzzy Sugeno", sub_style))
            story.append(HRFlowable(width="100%", thickness=2, color=HEADER_COLOR, spaceAfter=8))
            story.append(Paragraph(title_laporan, judul_style))
            story.append(Spacer(1, 10))

        # ================= TABEL DATA =================
        total_cols = len(headers)
        if total_cols > 0:
            # Lebar area cetak = lebar A4 (21cm) - margin kiri (2cm) - margin kanan (2cm) = 17cm
            USABLE_WIDTH = 17 * cm

            # Style untuk isi sel agar teks bisa word-wrap
            cell_style = ParagraphStyle(
                "Cell", fontSize=9, fontName="Times-Roman",
                alignment=TA_LEFT, leading=11
            )
            header_style = ParagraphStyle(
                "CellHeader", fontSize=10, fontName="Times-Bold",
                alignment=TA_CENTER, textColor=colors.white, leading=12
            )

            # Tentukan lebar kolom: kolom sempit (No/Kode) fixed,
            # sisanya dibagi proporsional dari sisa ruang
            fixed_widths = {}
            for h in headers:
                if h.lower() in ["no", "no."]:
                    fixed_widths[h] = 1.2 * cm
                elif h.lower() in ["kode"]:
                    fixed_widths[h] = 2 * cm

            fixed_total = sum(fixed_widths.values())
            flexible_headers = [h for h in headers if h not in fixed_widths]
            remaining = USABLE_WIDTH - fixed_total

            # Bobot proporsi kolom fleksibel (silakan sesuaikan urutannya)
            weight_map = {"nama penyakit": 1.2, "deskripsi": 2.2, "solusi": 2.2}
            weights = [weight_map.get(h.lower(), 1.0) for h in flexible_headers]
            weight_sum = sum(weights) if weights else 1

            col_widths = []
            for h in headers:
                if h in fixed_widths:
                    col_widths.append(fixed_widths[h])
                else:
                    idx = flexible_headers.index(h)
                    col_widths.append(remaining * (weights[idx] / weight_sum))

            # Bungkus header & isi sel dengan Paragraph supaya bisa wrap
            wrapped_header = [Paragraph(str(h), header_style) for h in headers]
            wrapped_rows = []
            for row in data_rows:
                wrapped_rows.append([Paragraph(str(cell), cell_style) for cell in row])

            table_data = [wrapped_header] + wrapped_rows
            t_data = Table(table_data, colWidths=col_widths, repeatRows=1)

            t_data.setStyle(TableStyle([
                ("BACKGROUND",    (0,0), (-1,0), HEADER_COLOR),
                ("TEXTCOLOR",     (0,0), (-1,0), colors.white),
                ("ROWBACKGROUNDS",(0,1), (-1,-1), [colors.white, LIGHT_COLOR]),
                ("GRID",          (0,0), (-1,-1), 0.5, colors.HexColor("#cccccc")),
                ("TOPPADDING",    (0,0), (-1,-1), 6),
                ("BOTTOMPADDING", (0,0), (-1,-1), 6),
                ("LEFTPADDING",   (0,0), (-1,-1), 5),
                ("RIGHTPADDING",  (0,0), (-1,-1), 5),
                ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
            ]))
            story.append(t_data)
        else:
            story.append(Paragraph("Tidak ada data.", sub_style))
        # ================= TANDA TANGAN =================
        try:
            locale.setlocale(locale.LC_TIME, 'id_ID.UTF-8')
        except:
            pass
        
        hari_list = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"]
        bulan_list = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
        
        now = datetime.datetime.now()
        nama_hari = hari_list[now.weekday()]
        nama_bulan = bulan_list[now.month - 1]
        tanggal_str = f"Jakarta, {nama_hari}, {now.day} {nama_bulan} {now.year}"
        
        ttd_data = [
            ["", "", tanggal_str],
            ["", "", ""],
            ["", "", ""],
            ["", "", ""],
            ["", "", "Pudji Astuti, S. ST, BD"],
        ]
        t_ttd = Table(ttd_data, colWidths=[7*cm, 3.5*cm, 6.5*cm])
        t_ttd.setStyle(TableStyle([
            ('ALIGN', (2,0), (2,-1), 'CENTER'),
            ('VALIGN', (2,0), (2,-1), 'BOTTOM'),
            ('FONT', (2,0), (2,-1), 'Times-Roman', 10),
            ('FONT', (2,4), (2,4), 'Times-Bold', 10),
        ]))
        story.append(t_ttd)
        story.append(Spacer(1, 15))
        

        doc.build(story)
        Messagebox.show_info(
            f"Laporan PDF berhasil disimpan:\n{path}",
            title="Berhasil", parent=parent_window
        )
    except Exception as e:
        Messagebox.show_error(
            f"Terjadi kesalahan saat mencetak PDF:\n{e}",
            title="Error", parent=parent_window
        )
