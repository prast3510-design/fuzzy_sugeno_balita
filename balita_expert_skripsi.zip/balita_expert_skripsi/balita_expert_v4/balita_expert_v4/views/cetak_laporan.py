"""
views/cetak_laporan.py - Modul Cetak Laporan Diagnosis PDF
"""

import os
import datetime
import tkinter as tk
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from ttkbootstrap.dialogs import Messagebox
import database as db
import fuzzy as fz


def _row(obj):
    """Konversi sqlite3.Row ke dict biasa agar bisa pakai .get()"""
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return obj
    return dict(obj)


def cetak_laporan(parent_window, data: dict, nama_pasien: str = "", umur: str = ""):
    """
    Entry point utama. Tampilkan dialog preview lalu tawarkan simpan PDF/TXT.
    """
    dialog = LaporanDialog(parent_window, data, nama_pasien, umur)
    # grab_set SETELAH dialog selesai dibangun & di-update
    dialog.update_idletasks()
    dialog.grab_set()
    dialog.focus_force()


# ─────────────────────────────────────────────────────────────────────────────
class LaporanDialog(tk.Toplevel):
    def __init__(self, parent, data: dict, nama_pasien: str, umur: str):
        super().__init__(parent)
        self.title("Cetak Laporan Diagnosis")
        self.geometry("720x700")
        self.resizable(True, True)
        self.data = data

        # Pastikan dialog muncul di atas parent
        self.transient(parent)
        self.lift()

        self._build(nama_pasien, umur)

        # ── Refresh preview SETELAH semua widget selesai di-render ──
        self.after(100, self._refresh_preview)

    def _build(self, nama_pasien, umur):
        # ── Header toolbar ────────────────────────────────────────────────────
        bar = ttk.Frame(self)
        bar.pack(fill=X, padx=10, pady=8)

        ttk.Label(bar, text="Preview Laporan",
                  font=("Segoe UI", 13, "bold")).pack(side=LEFT)

        ttk.Button(bar, text="Simpan PDF",
                   bootstyle="success",
                   command=self._simpan_pdf).pack(side=RIGHT, padx=4)
        ttk.Button(bar, text="Simpan TXT",
                   bootstyle="info-outline",
                   command=self._simpan_txt).pack(side=RIGHT, padx=4)
        ttk.Button(bar, text="Tutup",
                   bootstyle="secondary-outline",
                   command=self.destroy).pack(side=RIGHT)

        ttk.Separator(self, orient=HORIZONTAL).pack(fill=X)

        # ── Form identitas pasien ─────────────────────────────────────────────
        id_frame = ttk.Frame(self)
        id_frame.pack(fill=X, padx=12, pady=8)

        ttk.Label(id_frame, text="Nama Pasien:",
                  font=("Segoe UI", 9)).grid(row=0, column=0, sticky=W, padx=(0, 6))
        self.var_nama = tk.StringVar(value=nama_pasien)
        ttk.Entry(id_frame, textvariable=self.var_nama,
                  width=28).grid(row=0, column=1, padx=(0, 20))

        ttk.Label(id_frame, text="Umur (bln):",
                  font=("Segoe UI", 9)).grid(row=0, column=2, sticky=W, padx=(0, 6))
        self.var_umur = tk.StringVar(value=umur)
        ttk.Entry(id_frame, textvariable=self.var_umur,
                  width=10).grid(row=0, column=3)

        ttk.Button(id_frame, text="Refresh Preview",
                   bootstyle="info-outline",
                   command=self._refresh_preview).grid(row=0, column=4, padx=(12, 0))

        ttk.Separator(self, orient=HORIZONTAL).pack(fill=X)

        # ── Area preview ──────────────────────────────────────────────────────
        preview_frame = ttk.Frame(self)
        preview_frame.pack(fill=BOTH, expand=True, padx=10, pady=8)

        # Inisialisasi txt SEBELUM scrollbar agar bisa di-link
        self.txt = tk.Text(
            preview_frame,
            font=("Courier New", 10),
            wrap=WORD,
            state=NORMAL,          # Biarkan NORMAL dulu, disable setelah isi
            bg="#fafafa",
            relief="flat",
            padx=12,
            pady=10,
        )
        sb = ttk.Scrollbar(preview_frame, orient=VERTICAL,
                            command=self.txt.yview, bootstyle="round")
        self.txt.configure(yscrollcommand=sb.set)
        sb.pack(side=RIGHT, fill=Y)
        self.txt.pack(side=LEFT, fill=BOTH, expand=True)

    # ── Buat teks laporan ─────────────────────────────────────────────────────
    def _buat_teks(self) -> str:
        hasil_list = self.data.get("hasil", [])
        gejala_ids = self.data.get("gejala_ids", [])

        nama = self.var_nama.get().strip() or "-"
        umur = self.var_umur.get().strip() or "-"
        tgl  = datetime.datetime.now().strftime("%d %B %Y, %H:%M WIB")

        W    = 68
        SEP  = "=" * W
        SEP2 = "-" * W

        lines = []
        lines.append(SEP)
        lines.append("         SISTEM PAKAR DIAGNOSIS PENYAKIT BALITA")
        lines.append("                 Metode Fuzzy Sugeno")
        lines.append(SEP)
        lines.append(f"  Tanggal Cetak : {tgl}")
        lines.append(f"  Nama Pasien   : {nama}")
        lines.append(f"  Umur Pasien   : {umur} bulan")
        lines.append(SEP)
        lines.append("")

        # Gejala terpilih
        lines.append("  GEJALA YANG DILAPORKAN")
        lines.append(SEP2)
        all_gejala = {g["id"]: _row(g) for g in db.get_all_gejala()}
        gejala_terpilih = [all_gejala[gid] for gid in gejala_ids if gid in all_gejala]
        if gejala_terpilih:
            for i, g in enumerate(gejala_terpilih, 1):
                lines.append(f"  {i:2}. [{g['kode']}] {g['nama']}")
        else:
            lines.append("  (tidak ada gejala terpilih)")
        lines.append("")

        # Hasil diagnosis
        lines.append("  HASIL DIAGNOSIS (TOP 5)")
        lines.append(SEP2)
        lines.append(f"  {'No':<4} {'Nama Penyakit':<32} {'Skor':>7}  Kepastian")
        lines.append(f"  {'--':<4} {'--------------------------------':<32} {'------':>7}  ---------")

        if hasil_list:
            for rank, h in enumerate(hasil_list[:5], 1):
                label = fz.label_kepastian(h.persentase)
                bar   = self._progress_bar(h.persentase)
                lines.append(f"  {rank:<4} {h.nama_penyakit:<32} {h.persentase:>6.1f}%  {label}")
                lines.append(f"       {bar}")
        else:
            lines.append("  Tidak ada penyakit yang cocok.")
        lines.append("")

        # Detail penyakit #1
        if hasil_list:
            top      = hasil_list[0]
            penyakit = _row(db.get_penyakit_by_id(top.penyakit_id))
            if penyakit:
                lines.append(f"  REKOMENDASI UTAMA: {penyakit['nama'].upper()}")
                lines.append(SEP2)
                lines.append("  Deskripsi:")
                lines += self._wrap(penyakit.get("deskripsi") or "-", W - 4, "    ")
                lines.append("")
                lines.append("  Solusi / Penanganan:")
                lines += self._wrap(penyakit.get("solusi") or "-", W - 4, "    ")
                lines.append("")

        lines.append(SEP2)
        lines.append("  CATATAN PENTING")
        lines.append(SEP2)
        lines += self._wrap(
            "Hasil diagnosis ini hanya sebagai referensi awal berdasarkan "
            "gejala yang dimasukkan dan tidak menggantikan pemeriksaan medis "
            "langsung. Segera konsultasikan dengan dokter atau tenaga kesehatan "
            "terdekat untuk diagnosis dan penanganan yang akurat.",
            W - 4, "  "
        )
        lines.append("")
        lines.append(SEP)

        return "\n".join(lines)

    @staticmethod
    def _progress_bar(pct: float, width: int = 38) -> str:
        filled = int(pct / 100 * width)
        return "[" + "#" * filled + "." * (width - filled) + f"] {pct:.1f}%"

    @staticmethod
    def _wrap(text: str, width: int, indent: str = "") -> list:
        import textwrap
        return [indent + line for line in textwrap.fill(text, width).splitlines()]

    def _refresh_preview(self):
        """Isi ulang area preview dengan teks laporan terbaru."""
        try:
            teks = self._buat_teks()
            self.txt.configure(state=NORMAL)
            self.txt.delete("1.0", END)
            self.txt.insert("1.0", teks)
            self.txt.configure(state=DISABLED)
            # Scroll ke atas setelah diisi
            self.txt.yview_moveto(0)
        except Exception as e:
            # Jika ada error, tampilkan di preview agar mudah debug
            self.txt.configure(state=NORMAL)
            self.txt.delete("1.0", END)
            self.txt.insert("1.0", f"[ERROR saat generate preview]\n{e}")
            self.txt.configure(state=DISABLED)

    # ── Simpan TXT ────────────────────────────────────────────────────────────
    def _simpan_txt(self):
        import tkinter.filedialog as fd
        path = fd.asksaveasfilename(
            parent=self,
            defaultextension=".txt",
            filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")],
            initialfile=f"laporan_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.txt",
            title="Simpan Laporan sebagai TXT"
        )
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(self._buat_teks())
            Messagebox.show_info(
                f"Laporan berhasil disimpan:\n{path}",
                title="Berhasil", parent=self
            )
        except Exception as e:
            Messagebox.show_error(
                f"Gagal menyimpan file:\n{e}",
                title="Error", parent=self
            )

    # ── Simpan PDF ────────────────────────────────────────────────────────────
    def _simpan_pdf(self):
        try:
            from reportlab.lib.pagesizes import A4
            from reportlab.platypus import SimpleDocTemplate
            self._simpan_pdf_reportlab()
        except ImportError:
            jawab = Messagebox.yesno(
                title="reportlab Tidak Terinstal",
                message=(
                    "Library 'reportlab' tidak ditemukan, sehingga tidak bisa ekspor PDF.\n\n"
                    "Instal dengan perintah:\n  pip install reportlab\n\n"
                    "Simpan sebagai TXT sebagai gantinya?"
                ),
                parent=self,
            )
            if jawab == "Yes":
                self._simpan_txt()
        except Exception as e:
            Messagebox.show_error(
                f"Gagal membuat PDF:\n{e}",
                title="Error", parent=self
            )

    def _simpan_pdf_reportlab(self):
        """Simpan PDF dengan reportlab."""
        from reportlab.lib.pagesizes import A4
        from reportlab.lib import colors
        from reportlab.lib.units import cm
        from reportlab.platypus import (SimpleDocTemplate, Paragraph,
                                         Spacer, Table, TableStyle, HRFlowable)
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY
        import tkinter.filedialog as fd

        hasil_list = self.data.get("hasil", [])
        gejala_ids = self.data.get("gejala_ids", [])
        nama = self.var_nama.get().strip() or "-"
        umur = self.var_umur.get().strip() or "-"
        tgl  = datetime.datetime.now().strftime("%d %B %Y, %H:%M WIB")

        path = fd.asksaveasfilename(
            parent=self,
            defaultextension=".pdf",
            filetypes=[("PDF Files", "*.pdf"), ("All Files", "*.*")],
            initialfile=f"laporan_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf",
            title="Simpan Laporan PDF"
        )
        if not path:
            return

        doc = SimpleDocTemplate(path, pagesize=A4,
                                 leftMargin=2*cm, rightMargin=2*cm,
                                 topMargin=2*cm, bottomMargin=2*cm)

        HEADER_COLOR = colors.HexColor("#1a5276")
        LIGHT_COLOR  = colors.HexColor("#d6eaf8")
        GRAY_COLOR   = colors.HexColor("#888888")

        judul_style = ParagraphStyle("Judul", fontSize=15,
            fontName="Times-Bold", alignment=TA_CENTER,
            spaceAfter=4, textColor=HEADER_COLOR)
        sub_style = ParagraphStyle("Sub", fontSize=10,
            fontName="Times-Roman", alignment=TA_CENTER,
            spaceAfter=2, textColor=colors.HexColor("#555555"))
        section_style = ParagraphStyle("Section", fontSize=11,
            fontName="Times-Bold", spaceBefore=10, spaceAfter=4,
            textColor=HEADER_COLOR)
        body_style = ParagraphStyle("Body", fontSize=9,
            fontName="Times-Roman", leading=14,
            alignment=TA_JUSTIFY, spaceAfter=4)
        warn_style = ParagraphStyle("Warn", fontSize=8,
            fontName="Times-Italic", leading=12,
            textColor=GRAY_COLOR, alignment=TA_JUSTIFY)
        footer_style = ParagraphStyle("Footer", fontSize=7,
            fontName="Times-Italic", textColor=GRAY_COLOR,
            alignment=TA_CENTER)

        import os
        import auth
        from reportlab.platypus import Image

        story = []

        # Setup Kop Surat
        logo_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'assets', 'icons', 'logoibi.png')
        
        if os.path.exists(logo_path):
            logo = Image(logo_path, width=2.5*cm, height=2.5*cm)
            t_logo = Table([[logo]], colWidths=[16*cm])
            t_logo.setStyle(TableStyle([
                ('ALIGN', (0,0), (-1,-1), 'CENTER'),
                ('BOTTOMPADDING', (0,0), (-1,-1), 8)
            ]))
            story.append(t_logo)
            
            story.append(Paragraph("KLINIK BIDAN", ParagraphStyle(
                "KopJudul", fontSize=14, fontName="Times-Bold", alignment=TA_CENTER, spaceAfter=4, textColor=HEADER_COLOR
            )))
            story.append(Paragraph("Sistem Pakar Diagnosis Penyakit Balita Metode Fuzzy Sugeno", ParagraphStyle(
                "KopSub", fontSize=10, fontName="Times-Roman", alignment=TA_CENTER, spaceAfter=2
            )))
            story.append(Paragraph("Jl. Almubarok II No.32 RT005/RW010, Cipulir, Kebayoran Lama, Jakarta Selatan.", ParagraphStyle(
                "KopAlamat", fontSize=9, fontName="Times-Roman", alignment=TA_CENTER
            )))
            story.append(Spacer(1, 10))
            story.append(HRFlowable(width="100%", thickness=2, color=colors.black, spaceAfter=2))
            story.append(HRFlowable(width="100%", thickness=1, color=colors.black, spaceAfter=15))
            
            story.append(Paragraph("LAPORAN HASIL DIAGNOSIS", judul_style))
            story.append(Spacer(1, 10))
        else:
            story.append(Paragraph("SISTEM PAKAR DIAGNOSIS PENYAKIT BALITA", judul_style))
            story.append(Paragraph("Metode Fuzzy Sugeno", sub_style))
            story.append(HRFlowable(width="100%", thickness=2, color=HEADER_COLOR, spaceAfter=8))

        # Identitas
        id_data = [
            ["Tanggal Cetak", ":", tgl],
            ["Nama Pasien",   ":", nama],
            ["Umur Pasien",   ":", f"{umur} bulan"],
        ]
        t_id = Table(id_data, colWidths=[3.5*cm, 0.4*cm, None])
        t_id.setStyle(TableStyle([
            ("FONT",      (0,0), (-1,-1), "Times-Roman", 9),
            ("FONT",      (0,0), (0,-1),  "Times-Bold", 9),
            ("ROWBACKGROUNDS", (0,0), (-1,-1), [colors.white, LIGHT_COLOR]),
            ("TOPPADDING",    (0,0), (-1,-1), 4),
            ("BOTTOMPADDING", (0,0), (-1,-1), 4),
        ]))
        story.append(t_id)
        story.append(Spacer(1, 10))

        # Gejala
        story.append(Paragraph("Gejala yang Dilaporkan", section_style))
        story.append(HRFlowable(width="100%", thickness=0.5,
                                color=colors.grey, spaceAfter=4))
        all_gejala = {g["id"]: _row(g) for g in db.get_all_gejala()}
        gejala_terpilih = [all_gejala[gid] for gid in gejala_ids if gid in all_gejala]

        if gejala_terpilih:
            g_data = [["No", "Kode", "Nama Gejala"]]
            for i, g in enumerate(gejala_terpilih, 1):
                g_data.append([str(i), g["kode"], g["nama"]])
            t_g = Table(g_data, colWidths=[1*cm, 2.5*cm, None])
            t_g.setStyle(TableStyle([
                ("BACKGROUND",    (0,0), (-1,0), HEADER_COLOR),
                ("TEXTCOLOR",     (0,0), (-1,0), colors.white),
                ("FONT",          (0,0), (-1,0), "Times-Bold", 9),
                ("FONT",          (0,1), (-1,-1), "Times-Roman", 9),
                ("ROWBACKGROUNDS",(0,1), (-1,-1), [colors.white, LIGHT_COLOR]),
                ("GRID",          (0,0), (-1,-1), 0.3, colors.HexColor("#cccccc")),
                ("TOPPADDING",    (0,0), (-1,-1), 4),
                ("BOTTOMPADDING", (0,0), (-1,-1), 4),
                ("ALIGN",         (0,0), (0,-1), "CENTER"),
            ]))
            story.append(t_g)
        else:
            story.append(Paragraph("Tidak ada gejala terpilih.", body_style))
        story.append(Spacer(1, 10))

        # Hasil Diagnosis
        story.append(Paragraph("Hasil Diagnosis (Top 5)", section_style))
        story.append(HRFlowable(width="100%", thickness=0.5,
                                color=colors.grey, spaceAfter=4))

        WARNA_LABEL = {
            "Sangat Tinggi": colors.HexColor("#c0392b"),
            "Tinggi":        colors.HexColor("#d35400"),
            "Sedang":        colors.HexColor("#b7950b"),
            "Rendah":        colors.HexColor("#1e8449"),
            "Sangat Rendah": colors.HexColor("#717d7e"),
        }

        if hasil_list:
            h_data = [["No", "Nama Penyakit", "Skor (%)", "Kepastian"]]
            for rank, h in enumerate(hasil_list[:5], 1):
                label = fz.label_kepastian(h.persentase)
                h_data.append([str(rank), h.nama_penyakit,
                                f"{h.persentase:.1f}%", label])

            t_h = Table(h_data, colWidths=[1*cm, None, 2.5*cm, 3*cm])
            style_cmds = [
                ("BACKGROUND",    (0,0), (-1,0), HEADER_COLOR),
                ("TEXTCOLOR",     (0,0), (-1,0), colors.white),
                ("FONT",          (0,0), (-1,0), "Times-Bold", 9),
                ("FONT",          (0,1), (-1,-1), "Times-Roman", 9),
                ("ROWBACKGROUNDS",(0,1), (-1,-1), [colors.white, LIGHT_COLOR]),
                ("GRID",          (0,0), (-1,-1), 0.3, colors.HexColor("#cccccc")),
                ("TOPPADDING",    (0,0), (-1,-1), 5),
                ("BOTTOMPADDING", (0,0), (-1,-1), 5),
                ("ALIGN",         (2,0), (2,-1), "CENTER"),
                ("ALIGN",         (3,0), (3,-1), "CENTER"),
            ]
            for rank, h in enumerate(hasil_list[:5], 1):
                label = fz.label_kepastian(h.persentase)
                warna = WARNA_LABEL.get(label, colors.grey)
                style_cmds.append(("TEXTCOLOR", (3, rank), (3, rank), warna))
                style_cmds.append(("FONT", (3, rank), (3, rank),
                                   "Times-Bold", 9))
            t_h.setStyle(TableStyle(style_cmds))
            story.append(t_h)
        else:
            story.append(Paragraph(
                "Tidak ada penyakit yang cocok dengan gejala yang dipilih.",
                body_style))
        story.append(Spacer(1, 10))

        # Rekomendasi utama
        if hasil_list:
            top      = hasil_list[0]
            penyakit = _row(db.get_penyakit_by_id(top.penyakit_id))
            if penyakit:
                story.append(Paragraph(
                    f"Rekomendasi Utama: {penyakit['nama']}", section_style))
                story.append(HRFlowable(width="100%", thickness=0.5,
                                        color=colors.grey, spaceAfter=4))
                story.append(Paragraph("<b>Deskripsi:</b>", body_style))
                story.append(Paragraph(
                    penyakit.get("deskripsi") or "-", body_style))
                story.append(Spacer(1, 4))
                story.append(Paragraph("<b>Solusi / Penanganan:</b>", body_style))
                story.append(Paragraph(
                    penyakit.get("solusi") or "-", body_style))
                story.append(Spacer(1, 10))

        # Catatan penting
        story.append(HRFlowable(width="100%", thickness=0.5,
                                color=colors.grey, spaceAfter=4))
        story.append(Paragraph(
            "<b>Catatan Penting:</b> Hasil diagnosis ini hanya sebagai referensi awal "
            "berdasarkan gejala yang dimasukkan dan tidak menggantikan pemeriksaan medis "
            "langsung. Segera konsultasikan dengan dokter atau tenaga kesehatan terdekat "
            "untuk diagnosis dan penanganan yang akurat.",
            warn_style
        ))
        story.append(Spacer(1, 15))

        # Tanda Tangan
        import locale
        try:
            locale.setlocale(locale.LC_TIME, 'id_ID.UTF-8')
        except:
            pass
        
        hari_list = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"]
        bulan_list = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
        
        now = datetime.datetime.now()
        nama_hari = hari_list[now.weekday()]
        nama_bulan = bulan_list[now.month - 1]
        tanggal_str = f"Jakarta, {nama_hari}, {now.day} {nama_bulan} {now.year}"
        
        ttd_data = [
            ["", "", tanggal_str],
            ["", "", ""],
            ["", "", ""],
            ["", "", ""],
            ["", "", "Pudji Astuti, S. ST, BD"],
        ]
        t_ttd = Table(ttd_data, colWidths=[7*cm, 3.5*cm, 6.5*cm])
        t_ttd.setStyle(TableStyle([
            ('ALIGN', (2,0), (2,-1), 'CENTER'),
            ('VALIGN', (2,0), (2,-1), 'BOTTOM'),
            ('FONT', (2,0), (2,-1), 'Times-Roman', 10),
            ('FONT', (2,6), (2,6), 'Times-Bold', 10),
        ]))
        story.append(t_ttd)
        story.append(Spacer(1, 15))
        

        doc.build(story)
        Messagebox.show_info(
            f"Laporan PDF berhasil disimpan:\n{path}",
            title="Berhasil", parent=self
        )