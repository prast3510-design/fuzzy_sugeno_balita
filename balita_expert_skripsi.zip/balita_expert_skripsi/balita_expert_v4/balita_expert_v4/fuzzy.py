"""
fuzzy.py - Mesin Inferensi Fuzzy Sugeno
Sistem Pakar Diagnosis Penyakit Balita

Alur:
1. Fuzzifikasi  : nilai gejala (0/1) × bobot gejala × CF rule → α (firing strength)
2. Rule Eval    : hitung α tiap rule per penyakit
3. Defuzzifikasi: Weighted Average → z* = Σ(αᵢ × zᵢ) / Σαᵢ
                  zᵢ = nilai_cf rule (konstanta Sugeno orde-0)
"""

from collections import defaultdict
import database as db


# ─────────────────────────────────────────────────────────────────────────────
# Kelas bantu
# ─────────────────────────────────────────────────────────────────────────────

class HasilDiagnosis:
    """Mewakili satu baris hasil diagnosis."""

    def __init__(self, penyakit_id: int, nama_penyakit: str,
                 skor: float, persentase: float):
        self.penyakit_id  = penyakit_id
        self.nama_penyakit = nama_penyakit
        self.skor          = skor          # nilai defuzzifikasi (0–1)
        self.persentase    = persentase    # skor × 100 (%)

    def __repr__(self):
        return (f"<HasilDiagnosis penyakit={self.nama_penyakit!r} "
                f"skor={self.skor:.4f} ({self.persentase:.1f}%)>")


# ─────────────────────────────────────────────────────────────────────────────
# Tahap 1 – Fuzzifikasi
# ─────────────────────────────────────────────────────────────────────────────

def fuzzifikasi(gejala_terpilih_ids: set[int]) -> dict[int, float]:
    """
    Mengubah input crisp (id gejala yang dipilih) menjadi nilai fuzzy.

    Parameters
    ----------
    gejala_terpilih_ids : set[int]
        Kumpulan id gejala yang dicentang pengguna.

    Returns
    -------
    dict[int, float]
        Mapping gejala_id → nilai fuzzy (0.0 jika tidak dipilih, bobot jika dipilih).
    """
    semua_gejala = db.get_all_gejala()
    nilai_fuzzy: dict[int, float] = {}
    for g in semua_gejala:
        if g["id"] in gejala_terpilih_ids:
            nilai_fuzzy[g["id"]] = float(g["bobot"])   # dipilih → bobot gejala
        else:
            nilai_fuzzy[g["id"]] = 0.0                  # tidak dipilih → 0
    return nilai_fuzzy


# ─────────────────────────────────────────────────────────────────────────────
# Tahap 2 – Evaluasi Rule (fire strength α)
# ─────────────────────────────────────────────────────────────────────────────
def evaluasi_rule(nilai_fuzzy: dict[int, float], rules: list):
    """
    Evaluasi rule Sugeno dengan multi gejala (AND)
    α = MIN(μ gejala dalam rule)
    """
    from collections import defaultdict

    penyakit_rules = defaultdict(list)

    for rule in rules:
        penyakit_id = rule["penyakit_id"]
        output      = float(rule["output"])

        gejala_ids = rule["gejala"]

        # Ambil semua nilai μ gejala
        nilai_list = [nilai_fuzzy.get(gid, 0.0) for gid in gejala_ids]

        if not nilai_list:
            continue

        alpha = min(nilai_list)   # 🔥 INI KUNCI SUGENO AND

        if alpha > 0:
            penyakit_rules[penyakit_id].append((alpha, output))

    return dict(penyakit_rules)

# ─────────────────────────────────────────────────────────────────────────────
# Tahap 3 – Defuzzifikasi (Weighted Average)
# ─────────────────────────────────────────────────────────────────────────────

def defuzzifikasi(
    penyakit_rules: dict[int, list[tuple[float, float]]],
) -> dict[int, float]:
    """
    Weighted Average Sugeno:
        z* = Σ(αᵢ × zᵢ) / Σαᵢ

    Returns
    -------
    dict[int, float]
        penyakit_id → skor akhir (0–1).
    """
    hasil: dict[int, float] = {}
    for penyakit_id, pasangan in penyakit_rules.items():
        sum_alpha_z = sum(a * z for a, z in pasangan)
        sum_alpha   = sum(a     for a, _ in pasangan)

        if sum_alpha > 0:
            z_star = sum_alpha_z / sum_alpha
        else:
            z_star = 0.0

        hasil[penyakit_id] = min(z_star, 1.0)   # clamp ke [0,1]

    return hasil


# ─────────────────────────────────────────────────────────────────────────────
# Fungsi Utama – Jalankan Inferensi
# ─────────────────────────────────────────────────────────────────────────────

def jalankan_diagnosis(gejala_terpilih_ids: list[int]) -> list[HasilDiagnosis]:
    """
    Menjalankan seluruh pipeline Fuzzy Sugeno dan mengembalikan
    daftar HasilDiagnosis yang terurut dari skor tertinggi.

    Parameters
    ----------
    gejala_terpilih_ids : list[int]
        Id gejala yang dipilih pengguna.

    Returns
    -------
    list[HasilDiagnosis]
        Terurut descending berdasarkan skor; hanya yang skor > 0.
    """
    if not gejala_terpilih_ids:
        return []

    id_set = set(gejala_terpilih_ids)

    # Ambil semua rule dari database
    rules = db.get_rules_grouped()

    # Pipeline Fuzzy Sugeno
    nilai_fuzzy    = fuzzifikasi(id_set)
    penyakit_rules = evaluasi_rule(nilai_fuzzy, rules)
    skor_penyakit  = defuzzifikasi(penyakit_rules)

    if not skor_penyakit:
        return []

    # Ambil nama penyakit
    semua_penyakit = {p["id"]: p["nama"] for p in db.get_all_penyakit()}

    # Normalisasi opsional (agar total = 100% bila diinginkan tampil relatif)
    # Di sini kita tampilkan skor absolut × 100 sebagai persentase keyakinan.

    hasil = []
    for pid, skor in skor_penyakit.items():
        nama = semua_penyakit.get(pid, f"Penyakit #{pid}")
        hasil.append(HasilDiagnosis(
            penyakit_id   = pid,
            nama_penyakit = nama,
            skor          = skor,
            persentase    = round(skor * 100, 2),
        ))

    # Urutkan dari skor tertinggi
    hasil.sort(key=lambda h: h.skor, reverse=True)
    return hasil


# ─────────────────────────────────────────────────────────────────────────────
# Util – label tingkat kepastian
# ─────────────────────────────────────────────────────────────────────────────

def label_kepastian(persentase: float) -> str:
    """Mengkonversi persentase menjadi label deskriptif."""
    if persentase >= 80:
        return "Sangat Tinggi"
    elif persentase >= 60:
        return "Tinggi"
    elif persentase >= 40:
        return "Sedang"
    elif persentase >= 20:
        return "Rendah"
    else:
        return "Sangat Rendah"


def warna_kepastian(persentase: float) -> str:
    """Mengembalikan warna hex sesuai tingkat kepastian."""
    if persentase >= 80:
        return "#e74c3c"   # merah  → sangat tinggi → waspada
    elif persentase >= 60:
        return "#e67e22"   # oranye
    elif persentase >= 40:
        return "#f1c40f"   # kuning
    elif persentase >= 20:
        return "#27ae60"   # hijau
    else:
        return "#95a5a6"   # abu
